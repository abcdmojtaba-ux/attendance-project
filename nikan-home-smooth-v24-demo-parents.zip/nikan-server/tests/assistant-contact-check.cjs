
const assert=require('node:assert/strict');
const {answerSchoolQuestion:answer}=require('../lib/school-assistant');
const now=new Date('2026-11-03T10:00:00Z');
const data={
  classes:[{id:'m',name:'هفتم الف',shift:1}],
  students:[{id:'s1',name:'علی رضایی',classId:'m',fatherPhone:'09121111111',motherPhone:'09122222222',phone:'09123333333',active:true}],
  staff:[],assignments:[],submissions:[],attendance:[{id:'a1',studentId:'s1',type:'absent',date:'2026-11-03'}],exams:[]
};
let r=answer(data,'شماره پدر علی رضایی','manager',now);
assert.ok(r.message.includes('علی')||r.lines.some(l=>l.includes('09121111111')), JSON.stringify(r));
assert.ok(r.lines.some(l=>l.includes('09121111111')));
r=answer(data,'شماره تماس','manager',now);
assert.ok(r.message.includes('نام'));
r=answer(data,'اطلاعات دانش‌آموز علی رضایی','manager',now);
assert.ok(r.lines.some(l=>l.includes('غیبت')));
// teacher scope simulation - only empty students
const scoped={...data,students:[]};
r=answer(scoped,'شماره پدر علی رضایی','teacher',now);
assert.ok(!r.lines.some(l=>l.includes('09121111111')));
console.log('contact/info checks passed');
