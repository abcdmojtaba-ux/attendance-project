/**
 * سامانه نیکان — سرور Node.js (جایگزین Cloudflare Worker)
 * مسیرهای API و شکل پاسخ‌ها عمداً با نسخه قبلی یکی است تا اپ اندروید خراب نشود.
 */
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { db, ensureSchema, sqlite } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const MOTHER_KEY = process.env.MOTHER_KEY || '';

app.use(cors({ origin: true, credentials: true }));
// افزایش سقف بدنه برای بکاپ کامل با عکس‌های base64 دانش‌آموز/پرسنل
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

function json(res, data, status = 200) {
  res.status(status).json(data);
}

function motherKeyOk(req) {
  if (!MOTHER_KEY) return false;
  const h = req.headers['x-mother-key'] || req.headers['x-api-key'] || '';
  return String(h) === String(MOTHER_KEY);
}

function getAuth(body, req) {
  const a = (body && body.auth) || {};
  return {
    user: String(a.user || req.headers['x-auth-user'] || '').trim(),
    pass: String(a.pass || req.headers['x-auth-pass'] || '').trim(),
    role: String(a.role || req.headers['x-auth-role'] || '').trim().toLowerCase(),
    schoolId: String(a.schoolId || '').trim()
  };
}

/** احراز هویت ساده — سازگار با _compatNoAuth پنل مادر */
async function authenticateWrite(req, schoolId, body) {
  if (body && body._compatNoAuth) return { ok: true, role: 'mother' };
  if (body && body._motherPanel) return { ok: true, role: 'mother' };
  if (motherKeyOk(req)) return { ok: true, role: 'mother' };

  const auth = getAuth(body, req);
  if (auth.role === 'mother') {
    // در نسخه اول: اگر role مادر باشد و user/pass داشته باشد قبول (بعداً سخت‌تر می‌شود)
    if (auth.user && auth.pass) return { ok: true, role: 'mother' };
  }

  if (!schoolId) return { ok: false, error: 'school_required' };

  try {
    const row = db.prepare('SELECT data, manager_username FROM schools WHERE id = ?').bind(schoolId).first();
    if (!row) return { ok: false, error: 'school_not_found' };
    let school = {};
    try { school = JSON.parse(row.data || '{}'); } catch (e) {}
    const mu = String(school.managerUsername || school.managerUser || row.manager_username || '').trim();
    const mp = String(school.managerPassword || school.managerPass || '').trim();

    if (auth.role === 'manager' || auth.role === 'مدیر') {
      if (auth.user && auth.pass && auth.user === mu && auth.pass === mp) {
        return { ok: true, role: 'manager' };
      }
    }
    // معلم/معاون از appData
    const appRow = db.prepare('SELECT data FROM app_data WHERE school_id = ?').bind(schoolId).first();
    if (appRow) {
      let appData = {};
      try { appData = JSON.parse(appRow.data || '{}'); } catch (e) {}
      const staff = Array.isArray(appData.staff) ? appData.staff : [];
      for (const s of staff) {
        if (!s) continue;
        const u = String(s.user || s.username || '').trim();
        const p = String(s.pass || s.password || '').trim();
        if (u && p && u === auth.user && p === auth.pass) {
          const role = String(s.role || 'teacher').toLowerCase();
          return { ok: true, role: role.includes('deputy') || role.includes('معاون') ? 'deputy' : 'teacher' };
        }
      }
      if (appData.managerUser && appData.managerPass) {
        if (auth.user === String(appData.managerUser) && auth.pass === String(appData.managerPass)) {
          return { ok: true, role: 'manager' };
        }
      }
    }
  } catch (e) {
    console.error('authenticateWrite', e);
  }
  return { ok: false, error: 'auth_required' };
}

function loadSchoolRow(id) {
  const row = db.prepare('SELECT id, code, manager_username, data, updated_at FROM schools WHERE id = ?').bind(id).first();
  if (!row) return null;
  try {
    const data = JSON.parse(row.data || '{}');
    return Object.assign({}, data, { id: row.id, code: row.code || data.code, updatedAtMs: row.updated_at });
  } catch (e) {
    return { id: row.id, code: row.code };
  }
}

function saveSchoolRow(school) {
  const id = String(school.id || '');
  if (!id) throw new Error('school id required');
  const code = String(school.code || '');
  const managerUsername = String(school.managerUsername || school.managerUser || '');
  const data = JSON.stringify(school);
  const now = Date.now();
  db.prepare(
    `INSERT INTO schools (id, code, manager_username, data, updated_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET code = excluded.code, manager_username = excluded.manager_username,
       data = excluded.data, updated_at = excluded.updated_at`
  ).bind(id, code, managerUsername, data, now).run();
}

function loadAppData(schoolId) {
  const row = db.prepare('SELECT data, updated_at FROM app_data WHERE school_id = ?').bind(schoolId).first();
  if (!row) return { _hadRow: false, classes: [], students: [], staff: [], assignments: [], attendance: [], submissions: [] };
  try {
    const data = JSON.parse(row.data || '{}');
    data._hadRow = true;
    data.updatedAtMs = row.updated_at;
    return data;
  } catch (e) {
    return { _hadRow: true, classes: [], students: [], staff: [], assignments: [], attendance: [] };
  }
}

function saveAppData(schoolId, data) {
  const payload = Object.assign({}, data);
  delete payload._hadRow;
  delete payload._fromCache;
  payload.updatedAtMs = Date.now();
  const str = JSON.stringify(payload);
  db.prepare(
    `INSERT INTO app_data (school_id, data, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(school_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`
  ).bind(schoolId, str, payload.updatedAtMs).run();
}

/** بعد از بازنشانی سال: رکوردهای قدیمی عملکرد را نپذیر (جلوگیری از پر شدن دوباره توسط مرورگر دیگر) */
function filterPostResetPerformance(prev, incomingList, body) {
  // فقط بکاپ کامل عمدی — نه هر structure write با confirmStructureWrite
  if (body && (body._fullRestore === true || body._bypassPerfFilter === true)) {
    return incomingList;
  }
  const clearedAt = Number(prev && prev._performanceClearedAt) || 0;
  if (!clearedAt || !Array.isArray(incomingList)) return incomingList;
  return incomingList.filter((x) => {
    if (!x) return false;
    let t = Number(x.createdAtMs) || Number(x.createdAt) || 0;
    // اگر معلم همین الان فرستاده و timestamp نداشت، از updatedAtMs بدنه استفاده کن
    if (!t && body && Number(body.updatedAtMs) > clearedAt && (x.fromTeacher || x.submissionId)) {
      t = Number(body.updatedAtMs);
    }
    if (!t) return false;
    return t > clearedAt;
  });
}

function mergeAttendanceSafe(prev, incoming, body) {
  const filtered = filterPostResetPerformance(prev, incoming, body);
  return propagateExcusedSameDay(mergeById(prev.attendance || [], filtered));
}

function mergeListSafe(prev, field, incoming, body) {
  const filtered = filterPostResetPerformance(prev, incoming, body);
  return mergeById(prev[field] || [], filtered);
}

function mergeById(prevList, incoming) {
  const map = {};
  (Array.isArray(prevList) ? prevList : []).forEach((x) => {
    if (x && x.id) map[String(x.id)] = x;
  });
  if (Array.isArray(incoming)) {
    incoming.forEach((x) => {
      if (!x || !x.id) return;
      const old = map[String(x.id)];
      if (!old) {
        map[String(x.id)] = Object.assign({}, x);
        return;
      }
      const merged = Object.assign({}, old, x);
      // موجه بودن را از هر طرف که ست شده حفظ کن (race دو موجه هم‌زمان)
      if (old.excused || x.excused) merged.excused = true;
      if (old.justified || x.justified) merged.justified = true;
      if (old.scoreLocked || x.scoreLocked) merged.scoreLocked = true;
      if (old.fromDiscipline || x.fromDiscipline) merged.fromDiscipline = true;
      if (old.fromManager || x.fromManager) merged.fromManager = true;
      // ارسال: done هرگز به pending برنگردد
      (function () {
        const rank = { voided: 4, cancelled: 4, done: 3, reviewed: 3, archived: 2, pending: 1 };
        const os = String(old.status || 'pending');
        const ns = String(x.status || merged.status || 'pending');
        const or = rank[os] || 0;
        const nr = rank[ns] || 0;
        if (or > nr) {
          merged.status = old.status;
          if (old.reviewedAt) merged.reviewedAt = old.reviewedAt;
          if (old.reviewedBy) merged.reviewedBy = old.reviewedBy;
          if (old.voided) merged.voided = true;
          if (old.cancelled) merged.cancelled = true;
        } else if (old.reviewedAt && (!x.reviewedAt || Number(old.reviewedAt) >= Number(x.reviewedAt || 0))) {
          merged.reviewedAt = old.reviewedAt;
          if (old.reviewedBy) merged.reviewedBy = old.reviewedBy;
        }
      })();
      // پیام: readBy اجتماع
      if (Array.isArray(old.readBy) || Array.isArray(x.readBy)) {
        const rb = {};
        (old.readBy || []).forEach(function (k) { if (k) rb[String(k)] = true; });
        (x.readBy || []).forEach(function (k) { if (k) rb[String(k)] = true; });
        merged.readBy = Object.keys(rb);
      }
      if (x.typeName) merged.typeName = x.typeName;
      else if (old.typeName) merged.typeName = old.typeName;
      if (merged.excused || merged.justified) {
        if (parseFloat(x.scoreDeduct) === 0 || parseFloat(old.scoreDeduct) === 0 || x.excused || old.excused) {
          merged.scoreDeduct = 0;
        }
      }
      // کسر قفل‌شده انضباطی را از دست نده
      if (merged.scoreLocked) {
        const sa = parseFloat(old.scoreDeduct);
        const sb = parseFloat(x.scoreDeduct);
        if (x.scoreLocked && !isNaN(sb)) merged.scoreDeduct = sb;
        else if (old.scoreLocked && !isNaN(sa) && (x.scoreDeduct == null || isNaN(sb))) merged.scoreDeduct = sa;
      }
      // عکس: خالی روی یکی، عکس طرف دیگر را پاک نکند
      if (!(x.photo || x.image) && (old.photo || old.image)) {
        merged.photo = old.photo || '';
        if (old.image) merged.image = old.image;
      }
      if (Array.isArray(x.photos) && x.photos.length) merged.photos = x.photos;
      else if (Array.isArray(old.photos) && old.photos.length) merged.photos = old.photos;
      map[String(x.id)] = merged;
    });
  }
  return Object.keys(map).map((k) => map[k]);
}

/** اگر یک غیبت موجه شد، همه غیبت‌های همان دانش‌آموز در همان روز موجه شوند */
function propagateExcusedSameDay(attendance) {
  if (!Array.isArray(attendance) || !attendance.length) return attendance || [];
  const excusedDays = {};
  attendance.forEach((a) => {
    if (!a || !a.studentId) return;
    const t = a.type || '';
    if (t !== 'absent' && t !== 'late') return;
    if (!(a.excused || a.justified || (parseFloat(a.scoreDeduct) === 0 && a.scoreLocked))) return;
    const day = String(a.date || '').slice(0, 10);
    if (!day) return;
    excusedDays[String(a.studentId) + '|' + day] = true;
  });
  if (!Object.keys(excusedDays).length) return attendance;
  return attendance.map((a) => {
    if (!a || !a.studentId) return a;
    const t = a.type || '';
    if (t !== 'absent' && t !== 'late') return a;
    const day = String(a.date || '').slice(0, 10);
    if (!excusedDays[String(a.studentId) + '|' + day]) return a;
    if (a.excused && a.justified && parseFloat(a.scoreDeduct) === 0) return a;
    const out = Object.assign({}, a);
    out.excused = true;
    out.justified = true;
    out.scoreDeduct = 0;
    out.scoreLocked = true;
    if ((out.note || '').indexOf('موجه') < 0) {
      out.note = (out.note ? out.note + ' · ' : '') + 'موجه';
    }
    return out;
  });
}

/** حذف آیتم‌ها بر اساس لیست شناسه‌ها */
function filterOutByIds(list, deletedIds) {
  if (!Array.isArray(list) || !list.length) return Array.isArray(list) ? list : [];
  if (!Array.isArray(deletedIds) || !deletedIds.length) return list;
  const del = {};
  deletedIds.forEach((id) => {
    if (id != null && id !== '') del[String(id)] = true;
  });
  return list.filter((x) => x && x.id && !del[String(x.id)]);
}

/** ادغام لیست شناسه‌های حذف‌شده (بدون تکرار، سقف ۵۰۰) */
function mergeDeletedIds(prevIds, incomingIds) {
  const set = {};
  (Array.isArray(prevIds) ? prevIds : []).forEach((id) => {
    if (id != null && id !== '') set[String(id)] = true;
  });
  (Array.isArray(incomingIds) ? incomingIds : []).forEach((id) => {
    if (id != null && id !== '') set[String(id)] = true;
  });
  const out = Object.keys(set);
  return out.length > 500 ? out.slice(-500) : out;
}

/** فیلتر حضور با کلیدهای پایدار (همیشه با type تا تأخیر≠غیبت) */
function filterAttendanceByDeletedKeys(list, keys) {
  if (!Array.isArray(list) || !list.length) return Array.isArray(list) ? list : [];
  if (!Array.isArray(keys) || !keys.length) return list;
  const dk = {};
  keys.forEach((k) => { if (k != null && k !== '') dk[String(k)] = true; });
  return list.filter((a) => {
    if (!a || !a.id) return false;
    const sid = String(a.studentId || '');
    const day = String(a.date || '');
    const typ = String(a.type || 'absent');
    const per = String(a.periodName || '');
    const sub = String(a.submissionId || '');
    if (dk['id:' + String(a.id)]) return false;
    if (sub && sid && dk['sub:' + sub + ':' + sid + ':' + typ]) return false;
    // کلید قدیمی بدون type فقط اگر type هم absent باشد اعمال نشود برای late
    // برای سازگاری: کلید بدون type فقط روی همان type=absent قدیمی‌ها
    if (sub && sid && dk['sub:' + sub + ':' + sid] && typ === 'absent') return false;
    if (sid && day && dk['day:' + sid + ':' + day + ':' + typ]) return false;
    if (sid && day && per && dk['per:' + sid + ':' + day + ':' + per + ':' + typ]) return false;
    if (sid && day && per && dk['per:' + sid + ':' + day + ':' + per] && typ === 'absent') return false;
    return true;
  });
}

/** اعمال حذف حضور و ارسال روی appData */
function applySoftDeletes(data, body) {
  const next = data || {};
  // شناسه‌های حذف‌شده را نگه دار تا بعداً برنگردند
  if (Array.isArray(body.deletedAttendanceIds) && body.deletedAttendanceIds.length) {
    next.deletedAttendanceIds = mergeDeletedIds(next.deletedAttendanceIds, body.deletedAttendanceIds);
  }
  if (Array.isArray(body.deletedAttendanceKeys) && body.deletedAttendanceKeys.length) {
    next.deletedAttendanceKeys = mergeDeletedIds(next.deletedAttendanceKeys, body.deletedAttendanceKeys);
  }
  if (Array.isArray(body.deletedSubmissionIds) && body.deletedSubmissionIds.length) {
    next.deletedSubmissionIds = mergeDeletedIds(next.deletedSubmissionIds, body.deletedSubmissionIds);
  }
  // فیلتر attendance با id و کلید پایدار
  if (Array.isArray(next.deletedAttendanceIds) && next.deletedAttendanceIds.length) {
    next.attendance = filterOutByIds(next.attendance, next.deletedAttendanceIds);
  }
  if (Array.isArray(next.deletedAttendanceKeys) && next.deletedAttendanceKeys.length) {
    next.attendance = filterAttendanceByDeletedKeys(next.attendance, next.deletedAttendanceKeys);
  }
  // فیلتر submissions + attendance وابسته به submission
  if (Array.isArray(next.deletedSubmissionIds) && next.deletedSubmissionIds.length) {
    next.submissions = filterOutByIds(next.submissions, next.deletedSubmissionIds);
    const delSub = {};
    next.deletedSubmissionIds.forEach((id) => { delSub[String(id)] = true; });
    next.attendance = (Array.isArray(next.attendance) ? next.attendance : []).filter(
      (a) => !a || !a.submissionId || !delSub[String(a.submissionId)]
    );
  }
  // اگر خود رکورد voided فرستاده شده، از لیست submissions حذف کن
  if (Array.isArray(body.submissions)) {
    const voided = {};
    body.submissions.forEach((s) => {
      if (s && s.id && (s.status === 'voided' || s.voided || s.cancelled)) {
        voided[String(s.id)] = true;
      }
    });
    if (Object.keys(voided).length) {
      next.submissions = (Array.isArray(next.submissions) ? next.submissions : []).filter(
        (s) => s && s.id && !voided[String(s.id)]
      );
      next.attendance = (Array.isArray(next.attendance) ? next.attendance : []).filter(
        (a) => !a || !a.submissionId || !voided[String(a.submissionId)]
      );
      next.deletedSubmissionIds = mergeDeletedIds(next.deletedSubmissionIds, Object.keys(voided));
    }
  }
  return next;
}

// —— HTML صفحات ——
function sendHtml(res, file) {
  const p = path.join(__dirname, file);
  if (!fs.existsSync(p)) return res.status(404).send('Not found');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.sendFile(p);
}

function pageForHost(req) {
  const host = String(req.hostname || req.headers.host || '').toLowerCase().split(':')[0];
  if (host.startsWith('admin.') || host.includes('admin.nikan')) return 'mother.html';
  if (host.startsWith('panel.') || host.includes('panel.nikan')) return 'school.html';
  return null; // دامنه ناشناس → صفحه انتخاب
}

app.get('/', (req, res) => {
  const file = pageForHost(req);
  if (file) return sendHtml(res, file);
  return sendHtml(res, 'home.html');
});
app.get('/mother', (req, res) => sendHtml(res, 'mother.html'));
app.get('/index.html', (req, res) => {
  const file = pageForHost(req) || 'school.html';
  return sendHtml(res, file);
});
app.get('/school', (req, res) => sendHtml(res, 'school.html'));

// favicon ساده
app.get('/favicon.svg', (req, res) => {
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0f1c4d"/><text x="32" y="42" text-anchor="middle" font-size="32" font-family="Tahoma,sans-serif" font-weight="700" fill="#c9a84c">ن</text></svg>';
  res.type('image/svg+xml').send(svg);
});

app.get('/manifest.webmanifest', (req, res) => {
  res.json({
    name: 'سامانه نیکان',
    short_name: 'نیکان',
    start_url: '/school',
    display: 'standalone',
    background_color: '#0f1c4d',
    theme_color: '#0f1c4d',
    lang: 'fa',
    dir: 'rtl'
  });
});
app.get('/manifest-mother.webmanifest', (req, res) => {
  res.json({
    name: 'پنل مدیریتی سامانه نیکان',
    short_name: 'پنل مدیریت',
    start_url: '/mother',
    display: 'standalone',
    background_color: '#0f1c4d',
    theme_color: '#0f1c4d',
    lang: 'fa',
    dir: 'rtl'
  });
});

// —— Health ——
app.get('/api', (req, res) => json(res, { ok: true, service: 'nikan-node', time: Date.now() }));
app.get('/api/health', (req, res) => json(res, { ok: true, time: Date.now() }));

// —— Login (مدرسه) ——
app.post('/api/login', (req, res) => {
  try {
    const body = req.body || {};
    const user = String(body.user || '').trim();
    const pass = String(body.pass || '').trim();
    const code = String(body.code || '').trim();
    if (!user || !pass) return json(res, { ok: false, error: 'user_pass_required' }, 400);

    let school = null;
    if (code) {
      const row = db.prepare('SELECT id, code, data FROM schools WHERE code = ? LIMIT 1').bind(code).first();
      if (row) {
        try { school = Object.assign(JSON.parse(row.data || '{}'), { id: row.id, code: row.code }); } catch (e) {}
      }
    }
    if (!school) {
      // جستجو روی همه مدارس با نام کاربری مدیر
      const { results } = db.prepare('SELECT id, code, data FROM schools').bind().all();
      for (const r of results || []) {
        try {
          const d = JSON.parse(r.data || '{}');
          const mu = String(d.managerUsername || d.managerUser || '').trim();
          const mp = String(d.managerPassword || d.managerPass || '').trim();
          if (mu === user && mp === pass) {
            school = Object.assign(d, { id: r.id, code: r.code || d.code });
            break;
          }
        } catch (e) {}
      }
    }
    if (!school) return json(res, { ok: false, error: 'invalid_credentials' }, 401);

    const mu = String(school.managerUsername || school.managerUser || '').trim();
    const mp = String(school.managerPassword || school.managerPass || '').trim();
    if (user === mu && pass === mp) {
      return json(res, {
        ok: true,
        role: 'manager',
        school: {
          id: school.id,
          code: school.code,
          name: school.name,
          active: school.active !== false,
          expireDate: school.expireDate,
          modules: school.modules || [],
          shifts: school.shifts || 1
        }
      });
    }

    // staff
    const app = loadAppData(school.id);
    const staff = Array.isArray(app.staff) ? app.staff : [];
    for (const s of staff) {
      if (!s) continue;
      const u = String(s.user || s.username || '').trim();
      const p = String(s.pass || s.password || '').trim();
      if (u === user && p === pass) {
        const role = String(s.role || 'teacher');
        return json(res, {
          ok: true,
          role: role,
          staffId: s.id,
          school: { id: school.id, code: school.code, name: school.name }
        });
      }
    }
    return json(res, { ok: false, error: 'invalid_credentials' }, 401);
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— School by code ——
app.get('/api/schools/by-code/:code', (req, res) => {
  try {
    const code = String(req.params.code || '').trim();
    const row = db.prepare('SELECT id, code, data FROM schools WHERE code = ? LIMIT 1').bind(code).first();
    if (!row) return json(res, { ok: false, error: 'not_found' }, 404);
    let school = {};
    try { school = JSON.parse(row.data || '{}'); } catch (e) {}
    school.id = row.id;
    school.code = row.code || school.code;
    // رمز را برنگردان در پاسخ عمومی
    const safe = Object.assign({}, school);
    delete safe.managerPassword;
    delete safe.managerPass;
    return json(res, { ok: true, school: safe });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Schools list ——
app.get('/api/schools', (req, res) => {
  try {
    // فقط مادر یا با کلید مادر اجازه دیدن لیست کامل را دارد
    // (کلاینت‌های قدیمی که این endpoint را صدا می‌زنند لیست خالی امن می‌گیرند)
    const body = req.body || {};
    const roleHdr = String(req.headers['x-auth-role'] || '').toLowerCase();
    const isMother =
      roleHdr === 'mother' ||
      body._motherPanel === true ||
      body._compatNoAuth === true ||
      motherKeyOk(req);
    if (!isMother) {
      return json(res, { ok: true, schools: [], restricted: true });
    }
    ensureSchema();
    const { results } = db.prepare('SELECT id, code, manager_username, data, updated_at FROM schools ORDER BY updated_at DESC').bind().all();
    const schools = (results || []).map((r) => {
      try {
        const d = JSON.parse(r.data || '{}');
        const safe = Object.assign({}, d, { id: r.id, code: r.code || d.code, updatedAtMs: r.updated_at });
        // هرگز رمز را در لیست برنگردان
        delete safe.managerPassword;
        delete safe.managerPass;
        return safe;
      } catch (e) {
        return { id: r.id, code: r.code };
      }
    });
    return json(res, { ok: true, schools });
  } catch (e) {
    console.error(e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Create / update school ——
app.post('/api/schools', async (req, res) => {
  try {
    const body = req.body || {};
    // سازگاری با پنل مادر حفظ می‌شود؛ در غیر این صورت باید auth معتبر باشد
    const allowedByCompat = !!(body._compatNoAuth || body._motherPanel || motherKeyOk(req));
    if (!allowedByCompat) {
      const auth = await authenticateWrite(req, body.id || '', body);
      if (!auth.ok) {
        return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
      }
      // فقط مادر یا مدیر همان مدرسه می‌تواند ایجاد/ویرایش کند
      if (auth.role !== 'mother' && auth.role !== 'manager') {
        return json(res, { ok: false, error: 'forbidden' }, 403);
      }
    }
    const school = Object.assign({}, body);
    delete school.auth;
    delete school._compatNoAuth;
    delete school._motherPanel;
    if (!school.id) school.id = 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    school.updatedAtMs = Date.now();
    saveSchoolRow(school);
    return json(res, { ok: true, school: { id: school.id, code: school.code } });
  } catch (e) {
    console.error(e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Delete school ——
app.delete('/api/schools/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    // فقط مادر (با کلید یا فلگ سازگاری پنل مادر) اجازه حذف کامل مدرسه را دارد
    let isAllowed = !!(body._compatNoAuth || body._motherPanel || motherKeyOk(req));
    if (!isAllowed) {
      const auth = await authenticateWrite(req, id, body);
      isAllowed = auth.ok && auth.role === 'mother';
    }
    if (!isAllowed) {
      return json(res, { ok: false, error: 'auth_required', message: 'only mother can delete school' }, 401);
    }
    db.prepare('DELETE FROM schools WHERE id = ?').bind(id).run();
    db.prepare('DELETE FROM app_data WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM attendance_records WHERE school_id = ?').bind(id).run();
    db.prepare('DELETE FROM school_soft_meta WHERE school_id = ?').bind(id).run();
    return json(res, { ok: true, deleted: id });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Get one school ——
app.get('/api/schools/:id', (req, res) => {
  try {
    const school = loadSchoolRow(req.params.id);
    if (!school) return json(res, { ok: false, error: 'school_not_found' }, 404);
    // رمز مدیر را هرگز در پاسخ عمومی برنگردان
    const safe = Object.assign({}, school);
    delete safe.managerPassword;
    delete safe.managerPass;
    return json(res, { ok: true, school: safe });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— appData GET ——

/** شیفت کلاس/پرسنل را به 1 (صبح) یا 2 (عصر) نرمال کن */
function normShiftVal(v) {
  if (v == null || v === '') return 0;
  const n = parseInt(v, 10);
  if (n === 1 || n === 2) return n;
  const t = String(v).trim();
  if (/صبح|morning|am/i.test(t)) return 1;
  if (/عصر|شب|evening|pm/i.test(t)) return 2;
  return 0;
}

function staffMatchesId(st, staffId, username) {
  if (!st) return false;
  if (staffId && String(st.id) === String(staffId)) return true;
  if (username && String(st.username || '').toLowerCase() === String(username).toLowerCase()) return true;
  return false;
}

function assignmentIsMine(a, staffId, username) {
  if (!a) return false;
  const sid = staffId != null && staffId !== '' ? String(staffId) : '';
  const rawIds = [a.teacherId, a.teacherId2, a.teacherId3, a.staffId, a.teacher_id, a.userId];
  const ids = rawIds.filter((x) => x != null && x !== '').map(String);
  if (sid) {
    if (ids.indexOf(sid) >= 0) return true;
    // مقایسه عددی (12 === "12")
    const sidNum = Number(sid);
    if (Number.isFinite(sidNum) && ids.some((id) => Number(id) === sidNum)) return true;
  }
  const uname = username ? String(username).toLowerCase().trim() : '';
  if (uname) {
    const names = [a.teacherName, a.teacherUsername, a.username, a.teacher, a.name]
      .filter(Boolean)
      .map((x) => String(x).toLowerCase().trim());
    if (names.indexOf(uname) >= 0) return true;
  }
  return false;
}

/**
 * محدودسازی داده برای معلم / معاون — مدیر کل را می‌گیرد
 * query: scope=mine&role=teacher|deputy&staffId=&user=
 */
function scopeAppDataForViewer(full, query) {
  if (!full || typeof full !== 'object') return full;
  const scope = String((query && query.scope) || '').toLowerCase();
  if (scope !== 'mine') {
    const out = Object.assign({}, full);
    delete out._hadRow;
    out._scoped = false;
    return out;
  }
  const role = String((query && query.role) || '').toLowerCase();
  const staffId = query && query.staffId != null ? String(query.staffId) : '';
  const username = query && (query.user || query.username) != null ? String(query.user || query.username) : '';
  const isTeacher = role === 'teacher' || role === 'معلم' || role === 'دبیر';
  const isDeputy = role === 'deputy' || role === 'معاون' || role === 'assistant';

  if (!isTeacher && !isDeputy) {
    const out = Object.assign({}, full);
    delete out._hadRow;
    out._scoped = false;
    return out;
  }

  const staffList = Array.isArray(full.staff) ? full.staff : [];
  const me = staffList.find((st) => staffMatchesId(st, staffId, username)) || null;
  const myShift = me ? normShiftVal(me.shift) : 0;

  let classIds = {};
  let assignments = Array.isArray(full.assignments) ? full.assignments.slice() : [];

  if (isTeacher) {
    const tid = staffId || (me && me.id) || '';
    const tun = username || (me && me.username) || (me && me.name) || '';
    assignments = assignments.filter((a) => assignmentIsMine(a, tid, tun));
    // اگر با staffId چیزی پیدا نشد، با نام معلم در staff دوباره تلاش کن
    if (!assignments.length && me && me.name) {
      assignments = (Array.isArray(full.assignments) ? full.assignments : []).filter((a) =>
        assignmentIsMine(a, tid, String(me.name))
      );
    }
    assignments.forEach((a) => {
      if (a && a.classId) classIds[String(a.classId)] = true;
    });
  } else {
    // معاون: کلاس‌های شیفت خودش
    (Array.isArray(full.classes) ? full.classes : []).forEach((c) => {
      if (!c || !c.id) return;
      const cs = normShiftVal(c.shift);
      if (!myShift || !cs || cs === myShift) classIds[String(c.id)] = true;
    });
    assignments = assignments.filter((a) => a && a.classId && classIds[String(a.classId)]);
  }

  const classes = (Array.isArray(full.classes) ? full.classes : []).filter((c) => c && classIds[String(c.id)]);
  const students = (Array.isArray(full.students) ? full.students : []).filter(
    (st) => st && st.classId && classIds[String(st.classId)]
  );
  const studentIds = {};
  students.forEach((st) => {
    if (st && st.id) studentIds[String(st.id)] = true;
  });

  const attendance = (Array.isArray(full.attendance) ? full.attendance : []).filter((a) => {
    if (!a) return false;
    if (a.classId && classIds[String(a.classId)]) return true;
    if (a.studentId && studentIds[String(a.studentId)]) return true;
    if (isTeacher && staffId && String(a.teacherId || '') === String(staffId)) return true;
    return false;
  });

  let submissions = Array.isArray(full.submissions) ? full.submissions : [];
  if (isTeacher) {
    submissions = submissions.filter(
      (s) =>
        s &&
        (String(s.teacherId || '') === String(staffId || (me && me.id) || '') ||
          (s.classId && classIds[String(s.classId)]))
    );
  } else {
    submissions = submissions.filter((s) => s && s.classId && classIds[String(s.classId)]);
  }

  const exams = (Array.isArray(full.exams) ? full.exams : []).filter((e) => {
    if (!e) return false;
    if (e.classId && classIds[String(e.classId)]) return true;
    if (e.studentId && studentIds[String(e.studentId)]) return true;
    return false;
  });

  const teacherNotes = (Array.isArray(full.teacherNotes) ? full.teacherNotes : []).filter((n) => {
    if (!n) return false;
    if (isTeacher && staffId && String(n.teacherId || '') === String(staffId)) return true;
    if (n.classId && classIds[String(n.classId)]) return true;
    return false;
  });

  // پرسنل: فقط خود کاربر (معلم) یا همکاران هم‌شیفت (معاون) — بدون رمز بقیه
  let staffOut = [];
  if (me) {
    const self = Object.assign({}, me);
    staffOut = [self];
    if (isDeputy) {
      staffList.forEach((st) => {
        if (!st || !st.id) return;
        if (String(st.id) === String(me.id)) return;
        const ss = normShiftVal(st.shift);
        if (myShift && ss && ss !== myShift) return;
        const copy = Object.assign({}, st);
        // رمز بقیه را نفرست
        if (copy.pass) copy.pass = '';
        staffOut.push(copy);
      });
    }
  }

  const out = Object.assign({}, full, {
    classes,
    students,
    staff: staffOut,
    assignments,
    attendance,
    submissions,
    exams,
    teacherNotes,
    colleagues: [], // دفترچه پیامک همکاران فقط برای مدیر
    messages: Array.isArray(full.messages)
      ? full.messages.filter((m) => {
          if (!m) return false;
          if (isTeacher && staffId && (String(m.toId) === String(staffId) || String(m.fromId) === String(staffId)))
            return true;
          if (isDeputy) return true;
          return String(m.toId) === 'all_teachers' || String(m.toRole) === 'teacher';
        })
      : [],
    _scoped: true,
    _scopeRole: isTeacher ? 'teacher' : 'deputy',
    _scopeStaffId: staffId || (me && me.id) || '',
    _scopeShift: myShift || 0
  });
  delete out._hadRow;
  // رمز مدیر را به معلم/معاون نده
  if (out.managerPass) out.managerPass = '';
  return out;
}

app.get('/api/schools/:id/appData', (req, res) => {
  try {
    const id = req.params.id;
    const full = loadAppData(id);
    // اگر نقش معلم/معاون در هدر باشد و scope نفرستاده، اجباری محدود کن
    const q = Object.assign({}, req.query || {});
    const roleH = String(req.headers['x-auth-role'] || '').toLowerCase();
    const isTeachH = roleH === 'teacher' || roleH === 'معلم' || roleH === 'دبیر';
    const isDepH = roleH === 'deputy' || roleH === 'معاون' || roleH === 'assistant';
    if (!q.scope && (isTeachH || isDepH)) {
      q.scope = 'mine';
      q.role = isDepH ? 'deputy' : 'teacher';
      if (req.headers['x-staff-id']) q.staffId = String(req.headers['x-staff-id']);
      if (req.headers['x-auth-user']) q.user = String(req.headers['x-auth-user']);
    }
    const data = scopeAppDataForViewer(full, q);
    return json(res, { ok: true, data, updatedAt: data.updatedAtMs || full.updatedAtMs || 0 });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

/**
 * بازنشانی سال تحصیلی — یک تراکنش قطعی
 * body: { keepClasses, keepStudents, keepStaff, keepAssignments, managerAuthority }
 */
app.post('/api/schools/:id/reset-year', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok && !body._compatNoAuth && !body.managerAuthority) {
      return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
    }
    const keepC = body.keepClasses !== false;
    const keepS = body.keepStudents !== false;
    const keepT = body.keepStaff !== false;
    const keepA = body.keepAssignments === true;

    const result = sqlite.transaction(() => {
      const prev = loadAppData(id);
      const next = Object.assign({}, prev);
      const beforeAtt = Array.isArray(prev.attendance) ? prev.attendance.length : 0;
      const beforeSub = Array.isArray(prev.submissions) ? prev.submissions.length : 0;

      // عملکرد همیشه خالی — بدون استثنا
      const clearedAt = Date.now();
      next.attendance = [];
      next.submissions = [];
      next.exams = [];
      next.messages = [];
      next.teacherNotes = [];
      next.sampleQuestions = Array.isArray(prev.sampleQuestions) ? prev.sampleQuestions : [];
      next.absentSmsSent = {};
      next.deletedAttendanceIds = [];
      next.deletedSubmissionIds = [];
      next.deletedAttendanceKeys = [];
      next.resetYear = true;
      next.clearPerformance = true;
      next._performanceClearedAt = clearedAt;
      next._performanceEpoch = (Number(prev._performanceEpoch) || 0) + 1;
      next._blockSubRebuildUntil = clearedAt + 48 * 3600 * 1000;
      next.updatedAtMs = clearedAt;
      next._guard = 'node-reset-year-endpoint';

      if (!keepC) next.classes = [];
      if (!keepS) next.students = [];
      if (!keepT) {
        next.staff = [];
        next.colleagues = [];
      }
      if (!keepA) {
        next.assignments = [];
        next.deletedAssignmentIds = Array.isArray(prev.assignments)
          ? prev.assignments.map((a) => a && a.id).filter(Boolean).map(String)
          : [];
      }

      saveAppData(id, next);

      // دوباره بخوان و اگر هنوز پر بود زورکی خالی کن
      let check = loadAppData(id);
      if ((check.attendance || []).length > 0 || (check.submissions || []).length > 0) {
        check.attendance = [];
        check.submissions = [];
        check.exams = [];
        check.messages = [];
        check.teacherNotes = [];
        check.resetYear = true;
        check.clearPerformance = true;
        check._performanceClearedAt = clearedAt;
        check._performanceEpoch = next._performanceEpoch;
        check._blockSubRebuildUntil = next._blockSubRebuildUntil;
        check.updatedAtMs = Date.now();
        saveAppData(id, check);
      }

      let subTableDeleted = 0;
      let attTableDeleted = 0;
      try {
        const r1 = db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
        subTableDeleted = (r1 && r1.meta && r1.meta.changes) || 0;
      } catch (e) {
        console.warn('reset-year submissions', e.message);
      }
      try {
        const r2 = db.prepare('DELETE FROM attendance_records WHERE school_id = ?').bind(id).run();
        attTableDeleted = (r2 && r2.meta && r2.meta.changes) || 0;
      } catch (e) {
        console.warn('reset-year attendance_records', e.message);
      }

      // تأیید نهایی
      const final = loadAppData(id);
      const finalAtt = Array.isArray(final.attendance) ? final.attendance.length : -1;
      const finalSub = Array.isArray(final.submissions) ? final.submissions.length : -1;

      return {
        ok: finalAtt === 0 && finalSub === 0,
        guard: 'node-reset-year-endpoint',
        beforeAttendance: beforeAtt,
        beforeSubmissions: beforeSub,
        attendance: finalAtt,
        submissions: finalSub,
        exams: 0,
        messages: 0,
        subTableDeleted,
        attTableDeleted,
        _performanceClearedAt: clearedAt,
        _performanceEpoch: next._performanceEpoch,
        classes: (final.classes || []).length,
        students: (final.students || []).length,
        staff: (final.staff || []).length,
        assignments: (final.assignments || []).length
      };
    })();

    return json(res, result);
  } catch (e) {
    console.error('reset-year', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— appData PUT/POST ——
app.put('/api/schools/:id/appData', handleAppDataWrite);
app.post('/api/schools/:id/appData', handleAppDataWrite);

// مسیر مخصوص معلم (کلاینت به /appData/teacher می‌زند)
app.put('/api/schools/:id/appData/teacher', handleTeacherAppDataWrite);
app.post('/api/schools/:id/appData/teacher', handleTeacherAppDataWrite);

async function handleTeacherAppDataWrite(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    // تراکنش تا دو درخواست هم‌زمان (مثلاً دو موجه) همدیگر را overwrite نکنند
    const result = sqlite.transaction(() => {
      const prev = loadAppData(id);
      let next = Object.assign({}, prev);
      if (Array.isArray(body.attendance)) {
        next.attendance = mergeAttendanceSafe(prev, body.attendance, body);
      }
      if (Array.isArray(body.submissions)) {
        next.submissions = mergeListSafe(prev, 'submissions', body.submissions, body);
      }
      if (Array.isArray(body.exams)) {
        next.exams = mergeById(prev.exams || [], body.exams);
      }
      if (Array.isArray(body.messages)) {
        next.messages = mergeById(prev.messages || [], body.messages);
      }
      if (Array.isArray(body.teacherNotes)) {
        next.teacherNotes = mergeById(prev.teacherNotes || [], body.teacherNotes);
      }
      if (Array.isArray(body.sampleQuestions)) {
        next.sampleQuestions = mergeById(prev.sampleQuestions || [], body.sampleQuestions);
      }
      if (Array.isArray(body.staff) && body.staff.length) {
        next.staff = mergeById(prev.staff || [], body.staff);
      }
      if (body.staffSelfUpdate && body.staffSelfUpdate.id) {
        const sid = String(body.staffSelfUpdate.id);
        const staffList = Array.isArray(next.staff) ? next.staff.slice() : [];
        for (let i = 0; i < staffList.length; i++) {
          if (staffList[i] && String(staffList[i].id) === sid) {
            const upd = Object.assign({}, staffList[i]);
            if (body.staffSelfUpdate.photo !== undefined) upd.photo = body.staffSelfUpdate.photo || '';
            if (body.staffSelfUpdate.pass != null && String(body.staffSelfUpdate.pass).length >= 4) {
              upd.pass = String(body.staffSelfUpdate.pass);
            }
            staffList[i] = upd;
            break;
          }
        }
        next.staff = staffList;
      }
      next = applySoftDeletes(next, body);
      next.updatedAtMs = Date.now();
      next._guard = 'node-teacher';
      saveAppData(id, next);
      return { ok: true, guard: 'node-teacher' };
    })();
    return json(res, result);
  } catch (e) {
    console.error('teacher appData write', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

async function handleAppDataWrite(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);

    // مسیر soft (حضور و ...) — با compat مجاز؛ ساختار کلاس‌ها دست نمی‌خورد
    // تراکنش: دو موجه هم‌زمان همدیگر را overwrite نکنند
    if (body._softOnly === true) {
      const result = sqlite.transaction(() => {
        const prev = loadAppData(id);
        let next = Object.assign({}, prev);
        const softReset = body.resetYear === true || body.clearPerformance === true;
        if (softReset) {
          // بازنشانی: خالی واقعی — نه merge
          next.attendance = Array.isArray(body.attendance) ? body.attendance : [];
          next.submissions = Array.isArray(body.submissions) ? body.submissions : [];
          next.exams = Array.isArray(body.exams) ? body.exams : [];
          next.messages = Array.isArray(body.messages) ? body.messages : [];
          next.teacherNotes = Array.isArray(body.teacherNotes) ? body.teacherNotes : [];
          next.absentSmsSent = (body.absentSmsSent && typeof body.absentSmsSent === 'object') ? body.absentSmsSent : {};
          next.deletedAttendanceIds = Array.isArray(body.deletedAttendanceIds) ? body.deletedAttendanceIds : [];
          next.deletedSubmissionIds = Array.isArray(body.deletedSubmissionIds) ? body.deletedSubmissionIds : [];
          next.deletedAttendanceKeys = Array.isArray(body.deletedAttendanceKeys) ? body.deletedAttendanceKeys : [];
          next.resetYear = true;
          next.clearPerformance = true;
        } else if (Array.isArray(body.attendance)) {
          next.attendance = mergeAttendanceSafe(prev, body.attendance, body);
        }
        if (!softReset && Array.isArray(body.submissions)) {
          next.submissions = mergeListSafe(prev, 'submissions', body.submissions, body);
        }
        if (!softReset && Array.isArray(body.teacherNotes)) {
          next.teacherNotes = mergeById(prev.teacherNotes || [], body.teacherNotes);
        }
        if (!softReset && Array.isArray(body.exams)) {
          next.exams = mergeById(prev.exams || [], body.exams);
        }
        if (!softReset && Array.isArray(body.messages)) {
          next.messages = mergeById(prev.messages || [], body.messages);
        }
        if (Array.isArray(body.sampleQuestions)) {
          next.sampleQuestions = mergeById(prev.sampleQuestions || [], body.sampleQuestions);
        }
        if (Array.isArray(body.students) && body.students.length) {
          next.students = mergeById(prev.students || [], body.students);
        }
        if (Array.isArray(body.staff) && body.staff.length) {
          next.staff = mergeById(prev.staff || [], body.staff);
        }
        if (body.staffSelfUpdate && body.staffSelfUpdate.id) {
          const sid = String(body.staffSelfUpdate.id);
          const staffList = Array.isArray(next.staff) ? next.staff.slice() : [];
          for (let i = 0; i < staffList.length; i++) {
            if (staffList[i] && String(staffList[i].id) === sid) {
              const upd = Object.assign({}, staffList[i]);
              if (body.staffSelfUpdate.photo !== undefined) upd.photo = body.staffSelfUpdate.photo || '';
              if (body.staffSelfUpdate.pass != null && String(body.staffSelfUpdate.pass).length >= 4) {
                upd.pass = String(body.staffSelfUpdate.pass);
              }
              staffList[i] = upd;
              break;
            }
          }
          next.staff = staffList;
        }
        next = applySoftDeletes(next, body);
        // بعد از بازنشانی: هر حضور قدیمی را دوباره رد کن
        if (!softReset && Array.isArray(next.attendance) && Number(next._performanceClearedAt) > 0) {
          const clearedAt = Number(next._performanceClearedAt);
          next.attendance = next.attendance.filter((x) => {
            if (!x) return false;
            const t = Number(x.createdAtMs) || Number(x.createdAt) || 0;
            return t > clearedAt;
          });
        }
        if (body.managerUser) next.managerUser = String(body.managerUser);
        if (body.managerPass != null && String(body.managerPass).length >= 4) {
          next.managerPass = String(body.managerPass);
        }
        if (body.managerPhoto !== undefined) next.managerPhoto = body.managerPhoto;
        next.updatedAtMs = Date.now();
        next._guard = 'node-soft';
        saveAppData(id, next);
        return {
          ok: true,
          guard: 'node-soft',
          students: (next.students || []).length,
          staff: (next.staff || []).length,
          attendance: (next.attendance || []).length
        };
      })();
      return json(res, result);
    }

    // مسیر partial — تراکنش برای جلوگیری از race
    if (body._partialDelta === true) {
      const result = sqlite.transaction(() => {
        const prev = loadAppData(id);
        let next = Object.assign({}, prev);
        if (Array.isArray(body.classes) || body.deletedClassIds) {
          next.classes = mergeById(prev.classes, body.classes);
          if (Array.isArray(body.deletedClassIds) && body.deletedClassIds.length) {
            next.classes = filterOutByIds(next.classes, body.deletedClassIds);
          }
        }
        if (Array.isArray(body.students) || body.deletedStudentIds) {
          next.students = mergeById(prev.students, body.students);
          if (Array.isArray(body.deletedStudentIds) && body.deletedStudentIds.length) {
            next.students = filterOutByIds(next.students, body.deletedStudentIds);
          }
        }
        if (Array.isArray(body.staff) || body.deletedStaffIds) {
          next.staff = mergeById(prev.staff, body.staff);
          if (Array.isArray(body.deletedStaffIds) && body.deletedStaffIds.length) {
            next.staff = filterOutByIds(next.staff, body.deletedStaffIds);
          }
        }
        if (Array.isArray(body.assignments) || body.deletedAssignmentIds) {
          next.assignments = mergeById(prev.assignments, body.assignments);
          if (Array.isArray(body.deletedAssignmentIds) && body.deletedAssignmentIds.length) {
            next.assignments = filterOutByIds(next.assignments, body.deletedAssignmentIds);
          }
        }
        if (Array.isArray(body.attendance) || body.deletedAttendanceIds) {
          next.attendance = mergeAttendanceSafe(prev, body.attendance || [], body);
        }
        if (Array.isArray(body.submissions) || body.deletedSubmissionIds) {
          next.submissions = mergeListSafe(prev, 'submissions', body.submissions || [], body);
        }
        next = applySoftDeletes(next, body);
        if (body.managerUser !== undefined) next.managerUser = String(body.managerUser || '');
        if (body.managerPass != null && String(body.managerPass).length >= 4) next.managerPass = String(body.managerPass);
        if (body.smsConfig !== undefined) next.smsConfig = body.smsConfig;
        if (body.theme !== undefined) next.theme = body.theme;
        if (body.shifts !== undefined) next.shifts = body.shifts;
        next.updatedAtMs = Date.now();
        next._guard = 'node-partial';
        saveAppData(id, next);
        return {
          ok: true,
          guard: 'node-partial',
          classes: (next.classes || []).length,
          students: (next.students || []).length,
          staff: (next.staff || []).length
        };
      })();
      return json(res, result);
    }

    // نوشتن کامل / ساختار
    if (!auth.ok && !body._compatNoAuth && !body.managerAuthority && !body.deputyAuthority) {
      return json(res, { ok: false, error: auth.error || 'auth_required', guard: 'node-auth' }, 401);
    }

    const prev = loadAppData(id);

    // بازیابی کامل بکاپ (صفر تا صد)
    // فقط مدیر/مادر می‌توانند بازیابی کامل ساختار کنند — نه هر _compatNoAuth
    const isFullRestore =
      body.confirmStructureWrite === 'NIKAN-STRUCT-OK' &&
      (body.replaceStructure === true || body.structureWriteToken === true) &&
      (body._motherPanel === true || body.managerAuthority === true);

    let payload;
    if (isFullRestore) {
      // جایگزینی کامل از body — همه فیلدهای عملیاتی
      payload = Object.assign({}, prev, body, {
        updatedAtMs: Date.now(),
        _guard: 'node-full-restore'
      });
      // فقط فیلدهای کنترل را از payload نهایی پاک کن
      delete payload.auth;
      delete payload._compatNoAuth;
      delete payload._motherPanel;
      delete payload.managerAuthority;
      delete payload.deputyAuthority;
      delete payload.replaceStructure;
      delete payload.replaceAssignments;
      delete payload.structureWriteToken;
      delete payload.confirmStructureWrite;
      delete payload.clearStructure;
      delete payload._partialDelta;
      delete payload._softOnly;
      // آرایه‌ها را مستقیم از بکاپ بگیر (نه merge)
      if (Array.isArray(body.classes)) payload.classes = body.classes;
      if (Array.isArray(body.students)) payload.students = body.students;
      if (Array.isArray(body.staff)) payload.staff = body.staff;
      if (Array.isArray(body.assignments)) payload.assignments = body.assignments;
      // حضور/عملکرد فقط وقتی بکاپ کامل یا بازنشانی است عوض شود
      // وگرنه ذخیره ساختار (کلاس/معلم) حضور بازنشانی‌شده را دوباره پر می‌کند
      const allowPerfReplace =
        body._fullRestore === true ||
        body.resetYear === true ||
        body.clearPerformance === true ||
        body._bypassPerfFilter === true;
      if (allowPerfReplace) {
        if (Array.isArray(body.attendance)) payload.attendance = body.attendance;
        if (Array.isArray(body.submissions)) payload.submissions = body.submissions;
        if (Array.isArray(body.exams)) payload.exams = body.exams;
        if (Array.isArray(body.messages)) payload.messages = body.messages;
      } else {
        payload.attendance = prev.attendance || [];
        payload.submissions = prev.submissions || [];
        payload.exams = prev.exams || [];
        payload.messages = prev.messages || [];
        if (prev._performanceClearedAt) payload._performanceClearedAt = prev._performanceClearedAt;
      }
      if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
      if (Array.isArray(body.teacherNotes)) payload.teacherNotes = body.teacherNotes;
      if (Array.isArray(body.sampleQuestions)) payload.sampleQuestions = body.sampleQuestions;
      if (Array.isArray(body.disciplinePhotos)) payload.disciplinePhotos = body.disciplinePhotos;
      if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
      if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;
      if (body.smsConfig != null) payload.smsConfig = body.smsConfig;
      if (body.theme != null) payload.theme = body.theme;
      if (body.shifts != null) payload.shifts = body.shifts;
      if (body.managerUser != null) payload.managerUser = body.managerUser;
      if (body.managerPass != null) payload.managerPass = body.managerPass;
      if (body.managerPhoto != null) payload.managerPhoto = body.managerPhoto;
      if (body.absentSmsSent != null) payload.absentSmsSent = body.absentSmsSent;
      if (Array.isArray(body.deletedAttendanceIds)) payload.deletedAttendanceIds = body.deletedAttendanceIds;
      if (Array.isArray(body.deletedSubmissionIds)) payload.deletedSubmissionIds = body.deletedSubmissionIds;
      // بازنشانی عملکرد داخل full path هم اعمال شود
      if (body.resetYear === true || body.clearPerformance === true) {
        payload.attendance = Array.isArray(body.attendance) ? body.attendance : [];
        payload.submissions = Array.isArray(body.submissions) ? body.submissions : [];
        payload.exams = Array.isArray(body.exams) ? body.exams : [];
        payload.messages = Array.isArray(body.messages) ? body.messages : [];
        payload.resetYear = true;
        payload.clearPerformance = true;
        payload._performanceClearedAt = Date.now();
      } else if (body._fullRestore === true || body._bypassPerfFilter === true) {
        // فقط بکاپ کامل عمدی قفل را برمی‌دارد
        payload._performanceClearedAt = 0;
        payload.resetYear = false;
        payload.clearPerformance = false;
      } else if (prev._performanceClearedAt) {
        // ذخیره ساختار نباید قفل بازنشانی را بشکند
        payload._performanceClearedAt = prev._performanceClearedAt;
        payload.resetYear = false;
        payload.clearPerformance = false;
      }
      // محافظت ساختار: خالی/کوچک‌تر شدن غیرعمدی را رد کن (باگ چندکاربره قدیمی)
      const isMgrWrite = body.managerAuthority === true || body._fullRestore === true
        || body.clearStructure === true || auth.role === 'manager' || auth.role === 'mother';
      if (body.clearStructure !== true) {
        if (!(payload.classes || []).length && (prev.classes || []).length && body.keepClasses !== false) {
          payload.classes = prev.classes;
        }
        if (!(payload.students || []).length && (prev.students || []).length && body.keepStudents !== false) {
          payload.students = prev.students;
        }
        if (!(payload.staff || []).length && (prev.staff || []).length && body.keepStaff !== false) {
          payload.staff = prev.staff;
        }
        const clearAsg = body.replaceAssignments === true || body.clearAssignments === true
          || body.resetYear === true || body.keepAssignments === false;
        if (!(payload.assignments || []).length && (prev.assignments || []).length && !clearAsg) {
          payload.assignments = prev.assignments;
        }
        // اگر کسی (غیر مدیر) لیست کلاس/دانش‌آموز کوتاه‌تر فرستاد، prev را نگه دار
        if (!isMgrWrite) {
          const pc = (prev.classes || []).length;
          const ps = (prev.students || []).length;
          const pa = (prev.assignments || []).length;
          if (pc > 0 && (payload.classes || []).length > 0 && (payload.classes || []).length < pc * 0.5) {
            payload.classes = prev.classes;
          }
          if (ps > 0 && (payload.students || []).length > 0 && (payload.students || []).length < ps * 0.5) {
            payload.students = prev.students;
          }
          if (pa > 0 && (payload.assignments || []).length > 0 && (payload.assignments || []).length < pa * 0.5
              && !body.replaceAssignments) {
            payload.assignments = prev.assignments;
          }
        }
      }
    } else {
      // بازنشانی سال / پاک‌سازی عملکرد: آرایه خالی باید واقعاً جایگزین شود (نه merge)
      const isPerfReset = body.resetYear === true || body.clearPerformance === true;
      payload = Object.assign({}, prev, {
        attendance: isPerfReset
          ? (Array.isArray(body.attendance) ? body.attendance : [])
          : (Array.isArray(body.attendance) ? mergeAttendanceSafe(prev, body.attendance, body) : (prev.attendance || [])),
        submissions: isPerfReset
          ? (Array.isArray(body.submissions) ? body.submissions : [])
          : (Array.isArray(body.submissions) ? mergeListSafe(prev, 'submissions', body.submissions, body) : (prev.submissions || [])),
        exams: isPerfReset
          ? (Array.isArray(body.exams) ? body.exams : [])
          : (Array.isArray(body.exams) ? mergeById(prev.exams, body.exams) : (prev.exams || [])),
        messages: isPerfReset
          ? (Array.isArray(body.messages) ? body.messages : [])
          : (Array.isArray(body.messages) ? mergeById(prev.messages, body.messages) : (prev.messages || [])),
        updatedAtMs: Date.now(),
        _guard: isPerfReset ? 'node-reset-year' : 'node-appdata'
      });
      if (isPerfReset) {
        payload.resetYear = true;
        payload.clearPerformance = true;
        payload._performanceClearedAt = Date.now();
        payload.absentSmsSent = (body.absentSmsSent && typeof body.absentSmsSent === 'object') ? body.absentSmsSent : {};
        if (Array.isArray(body.deletedAttendanceIds)) payload.deletedAttendanceIds = body.deletedAttendanceIds;
        else payload.deletedAttendanceIds = [];
        if (Array.isArray(body.deletedSubmissionIds)) payload.deletedSubmissionIds = body.deletedSubmissionIds;
        else payload.deletedSubmissionIds = [];
        if (Array.isArray(body.deletedAttendanceKeys)) payload.deletedAttendanceKeys = body.deletedAttendanceKeys;
        else payload.deletedAttendanceKeys = [];
      } else {
        // فلگ ریست را پاک کن تا همیشه کلاینت‌ها را در حالت ریست نگه ندارد
        payload.resetYear = false;
        payload.clearPerformance = false;
      }

      const wantStruct =
        (body.managerAuthority === true || body.deputyAuthority === true || body._compatNoAuth || auth.role === 'mother' || auth.role === 'manager') &&
        (body.replaceStructure === true || body.structureWriteToken === true || body.confirmStructureWrite === 'NIKAN-STRUCT-OK');

      if (wantStruct || body.replaceStructure) {
        if (Array.isArray(body.classes)) payload.classes = body.clearStructure ? body.classes : mergeById(prev.classes, body.classes);
        if (Array.isArray(body.students)) payload.students = body.clearStructure ? body.students : mergeById(prev.students, body.students);
        if (Array.isArray(body.staff)) payload.staff = body.clearStructure ? body.staff : mergeById(prev.staff, body.staff);
        if (Array.isArray(body.assignments)) payload.assignments = body.clearStructure ? body.assignments : mergeById(prev.assignments, body.assignments);
      } else {
        // حفظ ساختار قبلی
        payload.classes = prev.classes || [];
        payload.students = prev.students || [];
        payload.staff = prev.staff || [];
        payload.assignments = prev.assignments || [];
      }

      if (body.smsConfig) payload.smsConfig = Object.assign({}, prev.smsConfig || {}, body.smsConfig);
      if (body.managerUser != null) payload.managerUser = body.managerUser;
      if (body.managerPass != null && String(body.managerPass).length > 0) payload.managerPass = body.managerPass;
      if (body.managerPhoto != null) payload.managerPhoto = body.managerPhoto;
      if (body.shifts != null) payload.shifts = body.shifts;
      if (body.theme != null) payload.theme = body.theme;
      if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
      if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;

      // هرگز ساختار را صفر نکن مگر clearStructure
      if (body.clearStructure !== true) {
        if ((prev.classes || []).length && !(payload.classes || []).length) payload.classes = prev.classes;
        if ((prev.students || []).length && !(payload.students || []).length) payload.students = prev.students;
        if ((prev.staff || []).length && !(payload.staff || []).length) payload.staff = prev.staff;
        if ((prev.assignments || []).length && !(payload.assignments || []).length) payload.assignments = prev.assignments;
      }

      // اعمال باطل/حذف حضور و ارسال (ساختار دست نخورده می‌ماند)
      payload = applySoftDeletes(payload, body);
    }

    saveAppData(id, payload);
    return json(res, {
      ok: true,
      guard: payload._guard,
      classes: (payload.classes || []).length,
      students: (payload.students || []).length,
      staff: (payload.staff || []).length,
      assignments: (payload.assignments || []).length
    });
  } catch (e) {
    console.error('appData write', e);
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— structure explicit ——
app.put('/api/schools/:id/appData/structure', handleStructure);
app.post('/api/schools/:id/appData/structure', handleStructure);

async function handleStructure(req, res) {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok && !body._compatNoAuth) {
      return json(res, { ok: false, error: 'structure_forbidden' }, 403);
    }
    const prev = loadAppData(id);
    // از prev شروع کن تا colleagues / sms / theme و بقیه پاک نشوند
    let nextClasses = Array.isArray(body.classes) ? body.classes : (prev.classes || []);
    let nextStudents = Array.isArray(body.students) ? body.students : (prev.students || []);
    let nextStaff = Array.isArray(body.staff) ? body.staff : (prev.staff || []);
    let nextAssign = Array.isArray(body.assignments) ? body.assignments : (prev.assignments || []);
    // جلوگیری از پاک شدن ساختار وقتی درخواست ناقص است (چند کاربر هم‌زمان)
    if (body.clearStructure !== true) {
      if ((prev.classes || []).length > 0 && nextClasses.length === 0) nextClasses = prev.classes;
      if ((prev.students || []).length > 0 && nextStudents.length === 0) nextStudents = prev.students;
      if ((prev.assignments || []).length > 0 && nextAssign.length === 0 && !body.replaceAssignments) nextAssign = prev.assignments;
      if ((prev.classes || []).length > 5 && nextClasses.length > 0 && nextClasses.length < (prev.classes || []).length * 0.5
          && body.managerAuthority !== true) {
        nextClasses = prev.classes;
        nextStudents = prev.students;
      }
    }
    const payload = Object.assign({}, prev, {
      classes: nextClasses,
      students: nextStudents,
      staff: nextStaff,
      assignments: nextAssign,
      updatedAtMs: Date.now(),
      _guard: 'node-structure'
    });
    // دفترچه همکاران + تنظیمات پیامک
    if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
    else if (!Array.isArray(payload.colleagues)) payload.colleagues = prev.colleagues || [];
    if (body.smsConfig != null) payload.smsConfig = body.smsConfig;
    if (Array.isArray(body.smsTemplates)) payload.smsTemplates = body.smsTemplates;
    if (body.theme != null) payload.theme = body.theme;
    if (body.rules != null) payload.rules = body.rules;
    if (body.managerUser != null) payload.managerUser = body.managerUser;
    if (body.managerPass != null && String(body.managerPass).length) payload.managerPass = body.managerPass;
    if (body.shifts != null) payload.shifts = body.shifts;
    if (Array.isArray(body.disciplineTypes)) payload.disciplineTypes = body.disciplineTypes;
    if (body.clearStructure === true) {
      payload.classes = Array.isArray(body.classes) ? body.classes : [];
      payload.students = Array.isArray(body.students) ? body.students : [];
      payload.staff = Array.isArray(body.staff) ? body.staff : [];
      payload.assignments = Array.isArray(body.assignments) ? body.assignments : [];
      if (Array.isArray(body.colleagues)) payload.colleagues = body.colleagues;
    }
    // قفل بازنشانی را نشکن
    if (prev._performanceClearedAt) {
      payload._performanceClearedAt = prev._performanceClearedAt;
      payload._performanceEpoch = prev._performanceEpoch;
      payload._blockSubRebuildUntil = prev._blockSubRebuildUntil;
    }
    delete payload._hadRow;
    saveAppData(id, payload);
    return json(res, {
      ok: true,
      guard: 'node-structure',
      classes: (payload.classes || []).length,
      students: (payload.students || []).length,
      staff: (payload.staff || []).length,
      assignments: (payload.assignments || []).length,
      colleagues: (payload.colleagues || []).length
    });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— Submissions ——
app.get('/api/schools/:id/submissions', (req, res) => {
  try {
    const id = req.params.id;
    const { results } = db
      .prepare('SELECT data FROM submissions WHERE school_id = ? ORDER BY created_at DESC LIMIT 2500')
      .bind(id)
      .all();
    let submissions = (results || [])
      .map((r) => {
        try { return JSON.parse(r.data); } catch (e) { return null; }
      })
      .filter(Boolean);

    // محدوده معلم/معاون (query یا هدر نقش)
    const q = Object.assign({}, req.query || {});
    const roleH = String(req.headers['x-auth-role'] || '').toLowerCase();
    if (!q.scope && (roleH === 'teacher' || roleH === 'deputy' || roleH === 'معلم' || roleH === 'معاون')) {
      q.scope = 'mine';
      q.role = (roleH === 'deputy' || roleH === 'معاون') ? 'deputy' : 'teacher';
      if (req.headers['x-staff-id']) q.staffId = String(req.headers['x-staff-id']);
      if (req.headers['x-auth-user']) q.user = String(req.headers['x-auth-user']);
    }
    if (String(q.scope || '').toLowerCase() === 'mine') {
      const role = String(q.role || '').toLowerCase();
      const staffId = q.staffId != null ? String(q.staffId) : '';
      const username = q.user != null ? String(q.user) : '';
      const full = loadAppData(id);
      const scoped = scopeAppDataForViewer(full, q);
      const allowClass = {};
      (scoped.classes || []).forEach((c) => { if (c && c.id) allowClass[String(c.id)] = true; });
      const isTeacher = role === 'teacher' || role === 'معلم' || role === 'دبیر';
      submissions = submissions.filter((sub) => {
        if (!sub) return false;
        if (isTeacher && staffId && String(sub.teacherId || '') === staffId) return true;
        if (sub.classId && allowClass[String(sub.classId)]) return true;
        return false;
      });
    }

    return json(res, { ok: true, submissions });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

app.post('/api/schools/:id/submissions', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const school = loadSchoolRow(id);
    if (!school) return json(res, { ok: false, error: 'school_not_found' }, 404);
    const subId = String(body.id || Date.now() + '-' + Math.random().toString(36).slice(2, 8));
    const assignId = body.assignId != null ? String(body.assignId) : null;
    const teacherId = body.teacherId != null ? String(body.teacherId) : null;
    const date = body.date != null ? String(body.date) : null;
    if (assignId && date && teacherId) {
      try {
        db.prepare('DELETE FROM submissions WHERE school_id = ? AND assign_id = ? AND date = ? AND teacher_id = ?')
          .bind(id, assignId, date, teacherId)
          .run();
      } catch (e) {}
    }
    let existingSub = null;
    try {
      const er = db.prepare('SELECT data FROM submissions WHERE id = ?').bind(subId).get();
      if (er && er.data) {
        try { existingSub = JSON.parse(er.data); } catch (e) {}
      }
    } catch (e) {}
    try {
      db.prepare('DELETE FROM submissions WHERE id = ?').bind(subId).run();
    } catch (e) {}
    const payload = Object.assign({}, body, { id: subId, syncedAt: Date.now() });
    if (existingSub) {
      const rank = { voided: 4, cancelled: 4, done: 3, reviewed: 3, archived: 2, pending: 1 };
      const or = rank[String(existingSub.status || 'pending')] || 0;
      const nr = rank[String(payload.status || 'pending')] || 0;
      if (or > nr) {
        payload.status = existingSub.status;
        if (existingSub.reviewedAt) payload.reviewedAt = existingSub.reviewedAt;
        if (existingSub.reviewedBy) payload.reviewedBy = existingSub.reviewedBy;
        if (existingSub.voided) payload.voided = true;
        if (existingSub.cancelled) payload.cancelled = true;
      }
    }
    delete payload.auth;
    delete payload.pass;
    delete payload._compatNoAuth;
    db.prepare(
      `INSERT INTO submissions (id, school_id, assign_id, teacher_id, date, data, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET school_id=excluded.school_id, assign_id=excluded.assign_id,
         teacher_id=excluded.teacher_id, date=excluded.date, data=excluded.data, created_at=excluded.created_at`
    )
      .bind(subId, id, assignId, teacherId, date, JSON.stringify(payload), Date.now())
      .run();
    return json(res, { ok: true, id: subId });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

app.delete('/api/schools/:id/submissions', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const subId = body && body.id ? String(body.id) : '';
    if (!subId) return json(res, { ok: false, error: 'id required' }, 400);
    db.prepare('DELETE FROM submissions WHERE school_id = ? AND id = ?').bind(id, subId).run();
    return json(res, { ok: true, deleted: subId, guard: 'node-sub-delete' });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// پاک‌سازی همه ارسال‌های حضور (بازنشانی سال)
app.post('/api/schools/:id/submissions/clear', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const auth = await authenticateWrite(req, id, body);
    if (!auth.ok && !body._compatNoAuth && !body.managerAuthority) {
      return json(res, { ok: false, error: auth.error || 'auth_required' }, 401);
    }
    db.prepare('DELETE FROM submissions WHERE school_id = ?').bind(id).run();
    return json(res, { ok: true, guard: 'node-sub-clear' });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
});

// —— Branding ——
app.get('/api/branding', (req, res) => {
  try {
    const row = db.prepare('SELECT data, updated_at FROM app_data WHERE school_id = ?').bind('__nikan_branding__').first();
    let data = {};
    if (row && row.data) {
      try { data = JSON.parse(row.data) || {}; } catch (e) {}
    }
    return json(
      res,
      Object.assign(
        {
          ok: true,
          logo: '',
          title: '',
          subtitle: '',
          announce: '',
          ad: '',
          adLink: '',
          bg: '#070b14',
          accent: '#38bdf8',
          text: '#e8eef7',
          card: '#111a2e',
          font: 'Tahoma, sans-serif',
          titleSize: '1.65rem',
          bodySize: '14.5px',
          bgImage: '',
          bgOverlay: 55,
          enabled: true,
          updatedAt: row && row.updated_at ? row.updated_at : 0
        },
        data,
        { ok: true }
      )
    );
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 503);
  }
});

app.put('/api/branding', handleBranding);
app.post('/api/branding', handleBranding);

function handleBranding(req, res) {
  try {
    const body = req.body || {};
    const roleHdr = String((body.auth && body.auth.role) || req.headers['x-auth-role'] || '').toLowerCase();
    const isMother = roleHdr === 'mother' || body._motherPanel === true || body._compatNoAuth === true || motherKeyOk(req);
    if (!isMother) return json(res, { ok: false, error: 'auth_required' }, 401);

    const payload = {
      logo: body.logo != null ? String(body.logo) : '',
      bgImage: body.bgImage != null ? String(body.bgImage) : '',
      enabled: body.enabled !== false,
      title: String(body.title || '').trim().slice(0, 80),
      subtitle: String(body.subtitle || '').trim().slice(0, 120),
      announce: String(body.announce || '').trim().slice(0, 300),
      ad: String(body.ad || '').trim().slice(0, 400),
      adLink: String(body.adLink || '').trim().slice(0, 300),
      bg: String(body.bg || '#070b14').slice(0, 20),
      accent: String(body.accent || '#38bdf8').slice(0, 20),
      text: String(body.text || '#e8eef7').slice(0, 20),
      card: String(body.card || '#111a2e').slice(0, 20),
      font: String(body.fontBody || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontTitle: String(body.fontTitle || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontSubtitle: String(body.fontSubtitle || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontBody: String(body.fontBody || body.font || 'Tahoma, sans-serif').slice(0, 120),
      fontAnnounce: String(body.fontAnnounce || body.font || 'Tahoma, sans-serif').slice(0, 120),
      titleSize: String(body.titleSize || '1.65rem').slice(0, 20),
      bodySize: String(body.bodySize || '14.5px').slice(0, 20),
      bgOverlay: Math.min(90, Math.max(0, parseInt(body.bgOverlay, 10) || 55)),
      updatedAtMs: Date.now()
    };
    db.prepare(
      `INSERT INTO app_data (school_id, data, updated_at) VALUES (?, ?, ?)
       ON CONFLICT(school_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at`
    )
      .bind('__nikan_branding__', JSON.stringify(payload), Date.now())
      .run();
    return json(res, { ok: true, saved: true, updatedAt: payload.updatedAtMs });
  } catch (e) {
    return json(res, { ok: false, error: String(e.message || e) }, 500);
  }
}

// —— SMS proxy (اختیاری) ——
app.post('/api/sms/send', async (req, res) => {
  try {
    const body = req.body || {};
    const provider = String(body.provider || 'melipayamak').toLowerCase();
    const username = String(body.username || '').trim();
    const password = String(body.password || body.apiKey || '').trim();
    const sender = String(body.sender || '').trim();
    const text = String(body.text || '');
    const apiUrl = String(body.apiUrl || '').trim();
    let phones = Array.isArray(body.phones) ? body.phones : [];
    phones = phones
      .map((p) => String(p || '').replace(/\D/g, ''))
      .map((p) => (p.startsWith('98') && p.length > 10 ? '0' + p.slice(2) : p))
      .filter((p) => p.length >= 10);

    if (!text) return json(res, { ok: false, error: 'empty_text', sent: 0, total: 0, results: [] }, 400);
    if (!phones.length) return json(res, { ok: false, error: 'no_phones', sent: 0, total: 0, results: [] }, 400);
    if (!username && !password) {
      return json(res, {
        ok: false,
        error: 'sms_credentials_missing',
        sent: 0,
        total: phones.length,
        results: [],
        hint: 'نام کاربری و رمز پنل پیامک را در تنظیمات مدرسه ذخیره کنید'
      }, 400);
    }

    const results = [];
    let sent = 0;

    async function postJson(url, payload) {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload)
      });
      const raw = await r.text();
      let data = null;
      try { data = JSON.parse(raw); } catch (e) { data = { raw }; }
      return { status: r.status, data, raw };
    }

    // —— ملی‌پیامک (Melipayamak) ——
    async function sendMelipayamak() {
      const url = apiUrl || 'https://rest.payamak-panel.com/api/SendSMS/SendSMS';
      for (const to of phones) {
        try {
          const { status, data, raw } = await postJson(url, {
            username,
            password,
            to,
            from: sender || '',
            text,
            isFlash: false
          });
          // Value > 0 یعنی recId موفق؛ منفی یا رشته خطا
          let val = data && (data.Value != null ? data.Value : data.value);
          if (val == null && data && data.RetStatus != null) val = data.RetStatus;
          const num = Number(val);
          const ok = (typeof val === 'string' && /^\d{5,}$/.test(val)) || (Number.isFinite(num) && num > 10);
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true, id: String(val) });
          } else {
            results.push({
              phone: to,
              ok: false,
              error: String(val != null ? val : (data && (data.StrRetStatus || data.message)) || raw || status)
            });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    // —— کاوه‌نگار ——
    async function sendKavenegar() {
      const key = password || username;
      const base = apiUrl || ('https://api.kavenegar.com/v1/' + encodeURIComponent(key) + '/sms/send.json');
      for (const to of phones) {
        try {
          const u = new URL(base);
          u.searchParams.set('receptor', to);
          u.searchParams.set('message', text);
          if (sender) u.searchParams.set('sender', sender);
          const r = await fetch(u.toString(), { method: 'GET' });
          const data = await r.json().catch(() => ({}));
          const ok = r.ok && data && data.return && Number(data.return.status) === 200;
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true, id: data.entries && data.entries[0] && data.entries[0].messageid });
          } else {
            results.push({ phone: to, ok: false, error: (data.return && data.return.message) || r.status });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    // —— عمومی: POST JSON به apiUrl ——
    async function sendGeneric() {
      if (!apiUrl) throw new Error('apiUrl لازم است');
      for (const to of phones) {
        try {
          const { status, data, raw } = await postJson(apiUrl, {
            username, password, apiKey: password, from: sender, sender, to, phone: to, text, message: text
          });
          const ok = status >= 200 && status < 300 && !(data && data.ok === false);
          if (ok) {
            sent += 1;
            results.push({ phone: to, ok: true });
          } else {
            results.push({ phone: to, ok: false, error: (data && (data.error || data.message)) || raw || status });
          }
        } catch (e) {
          results.push({ phone: to, ok: false, error: String(e.message || e) });
        }
      }
    }

    if (provider.includes('kavenegar') || provider === 'کاوه') {
      await sendKavenegar();
    } else if (provider.includes('meli') || provider.includes('payamak') || provider === 'melipayamak' || !apiUrl) {
      await sendMelipayamak();
    } else {
      await sendGeneric();
    }

    return json(res, {
      ok: sent > 0,
      sent,
      total: phones.length,
      results,
      error: sent === 0 ? (results[0] && results[0].error) || 'send_failed' : undefined
    });
  } catch (e) {
    console.error('sms/send', e);
    return json(res, { ok: false, error: String(e.message || e), sent: 0, total: 0, results: [] }, 500);
  }
});

// 404 API
app.use('/api', (req, res) => {
  json(res, { ok: false, error: 'route not found', path: req.path }, 404);
});

// خطا
app.use((err, req, res, next) => {
  console.error('unhandled', err);
  json(res, { ok: false, error: String(err.message || err) }, 500);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Nikan server on port', PORT);
  console.log('DB ready');
});
