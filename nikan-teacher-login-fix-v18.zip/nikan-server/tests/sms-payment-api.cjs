// CodeRabbit: integration tests with an isolated database; no gateway requests.
const assert=require('node:assert/strict'),D=require('better-sqlite3'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
(async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nikan-sms-pay-'));let child;try{
 const socket=http.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),DATA_DIR:dir,PUBLIC_BASE_URL:'',MOTHER_KEY:'synthetic-payment-mother'},stdio:'ignore'});
 const base='http://127.0.0.1:'+port;let ready=false;for(let i=0;i<100;i++){try{if((await fetch(base+'/api/health')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}assert.ok(ready);
 const db=new D(path.join(dir,'nikan.sqlite')),now=Date.now();const school={id:'s',code:'SMS',name:'Synthetic',active:true,expireDate:'2099-01-01',managerUsername:'manager',managerPassword:'synthetic-pass',smsCreditRial:700,smsMode:'both'};
 db.prepare('INSERT INTO schools(id,code,manager_username,data,updated_at) VALUES(?,?,?,?,?)').run('s','SMS','manager',JSON.stringify(school),now);db.close();
 const mother={'content-type':'application/json','X-Mother-Key':'synthetic-payment-mother'},manager={'content-type':'application/json','X-Auth-User':'manager','X-Auth-Pass':'synthetic-pass','X-Auth-Role':'manager'};
 async function req(p,opts={}){const response=await fetch(base+p,opts);return {status:response.status,data:await response.json()};}
 let r=await req('/api/sms/credit?schoolId=s',{headers:manager});assert.equal(r.data.onlinePaymentEnabled,false);assert.equal(r.data.chargeUrl,'');assert.equal(r.data.onlinePaymentReady,false);
 r=await req('/api/sms/platform',{method:'PUT',headers:mother,body:JSON.stringify({config:{onlinePaymentEnabled:false,cardNumber:'6037990000000000',chargeUrl:'https://panel.payamak-panel.com/'}})});assert.equal(r.status,200);
 r=await req('/api/sms/credit?schoolId=s',{headers:manager});assert.equal(r.data.cardNumber,'6037990000000000');assert.equal(r.data.chargeUrl,'');assert.equal(r.data.creditRial,700);
 r=await req('/api/sms/payments',{method:'POST',headers:manager,body:JSON.stringify({schoolId:'s',amountRial:10000})});assert.equal(r.status,400);assert.equal(r.data.error,'online_payment_disabled');
 r=await req('/api/sms/platform',{method:'PUT',headers:mother,body:JSON.stringify({config:{onlinePaymentEnabled:true}})});assert.equal(r.status,400);
 r=await req('/api/sms/platform',{method:'PUT',headers:mother,body:JSON.stringify({config:{onlinePaymentEnabled:true,paymentMerchant:'12345678-1234-1234-1234-123456789abc'}})});assert.equal(r.status,200);assert.equal(r.data.config.onlinePaymentEnabled,true);assert.equal(r.data.config.onlinePaymentReady,false);
 r=await req('/api/sms/platform?schoolId=s',{method:'PUT',headers:manager,body:JSON.stringify({config:{onlinePaymentEnabled:false}})});assert.equal(r.status,403);
 r=await req('/api/sms/payments',{method:'POST',headers:manager,body:JSON.stringify({schoolId:'other',amountRial:10000})});assert.ok([401,403].includes(r.status));
 const callback=await fetch(base+'/api/sms/payments/callback?order=fake&Authority=fake&Status=OK');assert.equal(callback.status,200);assert.ok((await callback.text()).includes('تأیید پرداخت انجام نشد'));
 r=await req('/api/sms/credit?schoolId=s',{headers:manager});assert.equal(r.data.creditRial,700);console.log('SMS payment API: card-only default, persistent switch, readiness, role/school isolation and fake callback passed');
 }finally{child?.kill();fs.rmSync(dir,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exitCode=1});
