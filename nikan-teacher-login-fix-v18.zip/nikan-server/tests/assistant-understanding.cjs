// CodeRabbit: Persian reporting regressions, no external model.
const assert=require('node:assert/strict');const {answerSchoolQuestion:answer}=require('../lib/school-assistant');const now=new Date('2026-11-03T10:00:00Z');
const data={classes:[{id:'m',name:'هفتم الف',shift:1},{id:'a',name:'هشتم ب',shift:2}],students:[],staff:[{id:'t1',name:'معلم صبح'},{id:'t2',name:'معلم عصر'}],assignments:[{id:'y1',dayOfWeek:1,classId:'m',teacherId:'t1'},{id:'y2',dayOfWeek:1,classId:'a',teacherId:'t2'},{id:'t1',dayOfWeek:2,classId:'m',teacherName:'معلم صبح'},{id:'t2',dayOfWeek:2,classId:'a',teacherName:'معلم عصر'}],submissions:[{id:'s',assignId:'y1',date:'2026-11-02',status:'approved'}]};
for(const q of ['دیروز کی حضور غیاب نفرسرتاده','دیروز کیا حضورغیاب نفرستادن','گزارش حضور و غیاب دیروز کی ارسال نکرده']){const r=answer(data,q,'manager',now);assert.equal(r.lines.length,1,q);assert.ok(r.lines[0].includes('معلم عصر'));}
for(const q of ['برنامه امروز شیف صبح رو بفرست','برنامع امرز شیفت ۱','برنامه امروز صبح']){const r=answer(data,q,'manager',now);assert.equal(r.lines.length,1,q);assert.ok(r.lines[0].includes('معلم صبح'));}
assert.equal(answer(data,'برنامه امروز عصر','manager',now).lines.length,1);assert.equal(answer(data,'برنامه امروز صبح و عصر','manager',now).lines.length,2);
assert.equal(answer(data,'دیروز صبح کی حضور غیاب نفرستاده','manager',now).lines.length,0);
const scoped={...data,classes:[data.classes[0]],assignments:data.assignments.filter(a=>a.classId==='m')};assert.equal(answer(scoped,'برنامه امروز عصر','teacher',now).lines.length,0);assert.equal(answer(scoped,'برنامه امروز عصر','deputy',now).lines.length,0);
assert.equal(answer(data,'دیروز کی حضور غیاب نفرسرتاده','manager',now,'','absence').lines.length,1);console.log('Persian misspelling, missing reports, morning/evening and scoped shift checks passed');

const namedShifts={...data,classes:data.classes.map((c,i)=>({...c,name:i?'عصر':'صبح'}))};assert.equal(answer(namedShifts,'برنامه امروز صبح و عصر','manager',now).lines.length,2);
const pendingShifts={...data,submissions:[{date:'2026-11-03',status:'pending',classId:'m'},{date:'2026-11-03',status:'pending',classId:'a'}]};assert.equal(answer(pendingShifts,'گزارش حضور در انتظار بررسی امروز صبح','manager',now).lines.length,1);
