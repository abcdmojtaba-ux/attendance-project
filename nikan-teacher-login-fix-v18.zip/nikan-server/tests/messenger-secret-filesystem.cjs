'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');const {spawn}=require('node:child_process');
(async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nikan-secret-fallback-'));const mod=path.resolve(__dirname,'../lib/messenger-secret.js');
 const worker=`const fs=require('node:fs'),path=require('node:path');fs.linkSync=()=>{let e=new Error('unsupported');e.code='ENOTSUP';throw e};let store=require(process.argv[1]).createSecretStore(undefined,process.argv[2]);let key=store.writeKey().key;let actual=fs.readFileSync(path.join(process.argv[2],'.messenger-secret'),'utf8');if(key.toString('hex')!==actual)process.exit(1);`;
 try{
  await Promise.all(Array.from({length:8},()=>new Promise((resolve,reject)=>{const child=spawn(process.execPath,['-e',worker,mod,dir],{stdio:'ignore'});child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(Error('fallback worker exited '+code)));})));
  const file=path.join(dir,'.messenger-secret');assert.equal(fs.statSync(file).mode&0o777,0o600);assert.match(fs.readFileSync(file,'utf8'),/^[0-9a-f]{64}$/);assert.deepEqual(fs.readdirSync(dir),['.messenger-secret']);
  const store=require(mod).createSecretStore(undefined,dir);fs.chmodSync(file,0o644);assert.equal(store.storedKey('file1:any').length,32);assert.equal(fs.statSync(file).mode&0o777,0o600);
  fs.unlinkSync(file);fs.symlinkSync('/dev/null',file);assert.throws(()=>store.writeKey(),/messenger_secret_permissions/);assert.ok(fs.lstatSync(file).isSymbolicLink());
  console.log('Unsupported hard links, concurrent initialization, permission repair and symlink refusal passed');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1});
