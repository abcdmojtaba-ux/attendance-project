// CodeRabbit: synthetic tests; no provider requests or parent data.
const assert=require('node:assert/strict'),D=require('better-sqlite3');const {createMessenger,phone}=require('../lib/messenger');
(async()=>{
 const sqlite=new D(':memory:');const date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran'}).format(new Date());
 const school={name:'Synthetic',active:true};
 const data={students:[{id:'s',name:'Synthetic',classId:'c',parentPhone:'۰۹۱۲۰۰۰۰۰۰۰',fatherPhone:'+98 912 000 0000',phones:['invalid']}],attendance:[{id:'a',studentId:'s',type:'absent',date}]};
 const calls=[];let outcome='ok';
 const m=createMessenger({sqlite,loadSchoolRow:()=>school,schoolUnavailable:()=>false,loadAppData:()=>data,normalizeDateToIso:d=>d,secret:'x'.repeat(32),transport:async(url,opts)=>{calls.push({url,body:JSON.parse(opts.body)});return {ok:outcome!=='reject',status:outcome==='reject'?400:200,json:async()=>outcome==='reject'?{ok:false}:{ok:true}};}});
 assert.equal(phone('+98 912 000 0000'),'09120000000');
 m.configure({enabled:true,provider:'eitaa',apiKey:'synthetic-key',contacts:{'09120000000':'chat123'}});
 assert.equal(m.publicConfig().key,undefined);assert.ok(!sqlite.prepare('SELECT data FROM messenger_config').get().data.includes('synthetic-key'));
 m.enqueue('one',{attendance:[]},data);m.enqueue('one',{attendance:[]},data);await m.tick();
 assert.equal(calls.length,1);assert.equal(calls[0].body.chat_id,'chat123');assert.equal(m.logs()[0].status,'accepted');await m.tick();assert.equal(calls.length,1);
 m.enqueue('two',{attendance:[]},data);data.attendance[0].excused=true;await m.tick();assert.equal(calls.length,1);assert.equal(m.logs().find(x=>x.school_id==='two').status,'cancelled');data.attendance[0].excused=false;
 // No manually entered contacts: normalize/dedupe stored phones and address the number directly.
 m.configure({enabled:true,provider:'eitaa',contacts:{}});m.enqueue('three',{attendance:[]},data);await m.tick();
 assert.equal(calls.length,2);assert.equal(calls[1].body.chat_id,'+989120000000');assert.equal(m.logs().find(x=>x.school_id==='three').status,'accepted');
 assert.match(calls[1].url,/^https:\/\/api\.uniom\.ir\/botsynthetic-key\/sendMessage$/);
 // Removed parent number must cancel a waiting send, rather than contacting the previous recipient.
 m.enqueue('removed',{attendance:[]},data);const saved=data.students[0];data.students[0]={...saved,parentPhone:'',fatherPhone:'',phones:[]};await m.tick();assert.equal(calls.length,2);assert.equal(m.logs().find(x=>x.school_id==='removed').status,'cancelled');data.students[0]=saved;
 // A legacy missing-contact row can be resumed without supplying a map; unknown outcomes are never retried.
 m.enqueue('legacy',{attendance:[]},data);sqlite.prepare("UPDATE messenger_outbox SET status='missing_contact' WHERE school_id='legacy'").run();
 assert.equal(m.resumeWaiting(),1);await m.tick();assert.equal(calls.length,3);assert.equal(calls[2].body.chat_id,'+989120000000');assert.equal(m.resumeWaiting(),0);
 m.enqueue('old',{attendance:[]},data);sqlite.prepare("UPDATE messenger_outbox SET status='missing_contact',event_date='2000-01-01' WHERE school_id='old'").run();assert.equal(m.resumeWaiting(),0);
 m.enqueue('stale',{attendance:[]},data);sqlite.prepare("UPDATE messenger_outbox SET event_date='2000-01-01' WHERE school_id='stale'").run();await m.tick();assert.equal(calls.length,3);assert.equal(m.logs().find(x=>x.school_id==='stale').status,'cancelled');
 outcome='reject';m.enqueue('rejected',{attendance:[]},data);await m.tick();assert.equal(m.logs().find(x=>x.school_id==='rejected').status,'rejected');await m.tick();assert.equal(calls.length,4);outcome='ok';
 m.configure({enabled:true,provider:'shad',serviceId:3,apiKey:'synthetic-shad',contacts:{}});m.enqueue('four',{attendance:[]},data);await m.tick();
 assert.equal(calls[4].body.data[0].mobile,'09120000000');assert.equal(m.logs().find(x=>x.school_id==='four').status,'unknown');await m.tick();assert.equal(calls.length,5);assert.equal(m.resumeWaiting(),0);
 // Disabling and school selection continue to prevent queue admission.
 m.configure({enabled:false,provider:'shad'});m.enqueue('disabled',{attendance:[]},data);assert.ok(!m.logs().some(x=>x.school_id==='disabled'));
 m.configure({enabled:true,provider:'shad',serviceId:3,schoolIds:['one']});m.enqueue('unselected',{attendance:[]},data);assert.ok(!m.logs().some(x=>x.school_id==='unselected'));
 sqlite.close();console.log('Stored phone addressing, optional overrides, legacy resume, encryption, deduplication, cancellation and uncertainty checks passed');
})().catch(e=>{console.error(e);process.exitCode=1});
