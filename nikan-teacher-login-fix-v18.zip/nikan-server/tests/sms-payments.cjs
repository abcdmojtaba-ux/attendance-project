// CodeRabbit: synthetic gateway only. Verifies accounting independent of browser callback claims.
const assert=require('node:assert/strict'),D=require('better-sqlite3');const {createSmsPayments}=require('../lib/sms-payments');
(async()=>{
 const db=new D(':memory:');db.exec("CREATE TABLE balance(id TEXT PRIMARY KEY,credit INTEGER);INSERT INTO balance VALUES('s',500);");
 let config={onlinePaymentEnabled:false,paymentMerchant:'12345678-1234-1234-1234-123456789abc'},calls=[],code=100,n=0;
 const m=createSmsPayments({sqlite:db,getConfig:()=>config,loadSchoolRow:id=>db.prepare('SELECT id,credit FROM balance WHERE id=?').get(id),getCredit:s=>s.credit,setCredit:(id,value)=>db.prepare('UPDATE balance SET credit=? WHERE id=?').run(value,id),schoolUnavailable:()=>false,baseUrl:'https://school.example',transport:async(url,opts)=>{
  const body=JSON.parse(opts.body);calls.push({url,body});if(url.endsWith('/request.json'))return {ok:true,json:async()=>({data:{code:100,authority:'A'+String(++n).padStart(35,'0')}})};
  return {ok:true,json:async()=>({data:{code,ref_id:123456}})};
 }});
 assert.equal(m.ready(),false);await assert.rejects(m.create('s',10000),/disabled/);config.onlinePaymentEnabled=true;
 assert.equal(m.ready(),true);for(const value of [-1,1.2,100000001,'10000'])await assert.rejects(m.create('s',value),/invalid_amount/);
 const order=await m.create('s',10000);assert.ok(order.paymentUrl.startsWith('https://payment.zarinpal.com/pg/StartPay/A'));assert.equal(calls[0].body.amount,10000);assert.equal(calls[0].body.currency,'IRR');assert.ok(calls[0].body.callback_url.includes(order.orderId));
 const authority=db.prepare('SELECT authority FROM sms_payments WHERE id=?').get(order.orderId).authority;
 await assert.rejects(m.verify(order.orderId,'fake','OK'),/invalid_payment/);assert.deepEqual(await m.verify(order.orderId,authority,'NOK'),{paid:false});assert.equal(db.prepare('SELECT credit FROM balance').get().credit,500);
 code=-51;await assert.rejects(m.verify(order.orderId,authority,'OK'),/not_verified/);assert.equal(db.prepare('SELECT credit FROM balance').get().credit,500);
 code=100;await Promise.all([m.verify(order.orderId,authority,'OK'),m.verify(order.orderId,authority,'OK')]);assert.equal(db.prepare('SELECT credit FROM balance').get().credit,10500);await m.verify(order.orderId,authority,'OK');assert.equal(db.prepare('SELECT credit FROM balance').get().credit,10500);
 const second=await m.create('s',20000);const a2=db.prepare('SELECT authority FROM sms_payments WHERE id=?').get(second.orderId).authority;code=101;config.onlinePaymentEnabled=false;await m.verify(second.orderId,a2,'OK');assert.equal(db.prepare('SELECT credit FROM balance').get().credit,30500);
 assert.ok(calls.filter(c=>c.url.endsWith('verify.json')).every(c=>Number.isSafeInteger(c.body.amount)&&c.body.merchant_id===config.paymentMerchant));
 console.log('SMS payments: disabled, validation, fake/cancelled/failed callback, verified credit, concurrent replay and recovery passed');db.close();
})().catch(e=>{console.error(e);process.exitCode=1});
