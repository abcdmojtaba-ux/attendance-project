'use strict';
const assert=require('node:assert/strict');
const http=require('node:http');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {spawn}=require('node:child_process');
const Database=require('better-sqlite3');
const {config,planQuestion}=require('../lib/assistant-planner');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nikan-ai-test-'));
let app, mock, observed=[], unblock;
(async()=>{
 assert.equal(config({NIKAN_AI_API_KEY:'synthetic',NIKAN_AI_MODEL:'mock',NIKAN_AI_ENDPOINT:'http://example.com/v1/chat/completions'}),null);
 mock=http.createServer((req,res)=>{
  let raw='';req.on('data',chunk=>raw+=chunk);req.on('end',()=>{
   const body=JSON.parse(raw);observed.push(body);
   if(body.messages[1].content.includes('simulate_failure')){res.writeHead(500);return res.end('{}');}
   if(body.messages[1].content.includes('hold_revocation')){unblock=()=>{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({choices:[{message:{content:JSON.stringify({intent:body.messages[1].content.includes('guide_test')?'guidance':'absence'})}}]}));};return;}
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({choices:[{message:{content:JSON.stringify({intent:body.messages[1].content.includes('guide_test')?'guidance':'absence'})}}]}));
  });
 });
 await new Promise(resolve=>mock.listen(0,'127.0.0.1',resolve));
 const endpoint='http://127.0.0.1:'+mock.address().port+'/v1/chat/completions';
 const settings={key:'synthetic',model:'mock',endpoint};
 assert.equal(await planQuestion('کیا نیومدن؟','',settings),'absence');
 const tmp=http.createServer();await new Promise(resolve=>tmp.listen(0,'127.0.0.1',resolve));const port=tmp.address().port;await new Promise(resolve=>tmp.close(resolve));
 app=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,DATA_DIR:dir,PORT:String(port),NIKAN_AI_API_KEY:'synthetic',NIKAN_AI_MODEL:'mock',NIKAN_AI_ENDPOINT:endpoint},stdio:['ignore','ignore','inherit']});
 const base='http://127.0.0.1:'+port;let ready=false;for(let i=0;i<100;i++){try{if((await fetch(base+'/api/health')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}assert.ok(ready);
 const db=new Database(path.join(dir,'nikan.sqlite')),now=Date.now();
 const school={id:'s',code:'S',name:'Synthetic',active:true,expireDate:'2099-01-01',managerUsername:'manager',managerPassword:'synthetic-password'};
 const data={managerUser:'manager',managerPass:'synthetic-password',classes:[{id:'c1',name:'هفتم الف'},{id:'c2',name:'هشتم ب'}],students:[{id:'p1',name:'علی',classId:'c1'},{id:'p2',name:'مینا',classId:'c2'}],staff:[{id:'t1',name:'Teacher',username:'teacher',pass:'synthetic-password',role:'teacher'}],assignments:[{id:'a1',teacherId:'t1',classId:'c1'}],attendance:[{id:'r1',studentId:'p1',classId:'c1',date:'2026-11-03',type:'absent'},{id:'r2',studentId:'p2',classId:'c2',date:'2026-11-03',type:'absent'}],submissions:[],exams:[]};
 db.prepare('INSERT INTO schools(id,code,manager_username,data,updated_at) VALUES(?,?,?,?,?)').run('s','S','manager',JSON.stringify(school),now);db.prepare('INSERT INTO app_data(school_id,data,updated_at) VALUES(?,?,?)').run('s',JSON.stringify(data),now);db.close();
 const headers={'content-type':'application/json','X-Auth-User':'teacher','X-Auth-Pass':'synthetic-password','X-Auth-Role':'manager'};
 let response=await fetch(base+'/api/schools/s/assistant/status',{headers});let result=await response.json();assert.equal(result.aiEnabled,true);
 response=await fetch(base+'/api/schools/s/assistant',{method:'POST',headers,body:JSON.stringify({question:'کیا نیومدن ۱۴۰۵/۰۸/۱۲'})});result=await response.json();assert.equal(response.status,200);assert.equal(result.mode,'ai');assert.deepEqual(result.answer.lines,['علی — هفتم الف']);
 response=await fetch(base+'/api/schools/s/assistant',{method:'POST',headers,body:JSON.stringify({question:'آزمون آنلاین guide_test'})});result=await response.json();assert.equal(response.status,200);assert.equal(result.mode,'ai');assert.ok(result.answer.lines.some(x=>x.includes('آزمون جدید')));
 response=await fetch(base+'/api/schools/s/assistant',{method:'POST',headers,body:JSON.stringify({question:'چطور حضور و غیاب ثبت کنم؟'})});result=await response.json();assert.match(result.answer.message,/راهنمای حضور و غیاب معلم/);
 const sent=JSON.stringify(observed.at(-1));assert.ok(!sent.includes('مینا'));assert.ok(!sent.includes('synthetic-password'));assert.ok(sent.includes('حضور و غیاب')); 
 response=await fetch(base+'/api/schools/s/assistant',{method:'POST',headers,body:JSON.stringify({question:'غایبان ۱۴۰۵/۰۸/۱۲ simulate_failure'})});result=await response.json();assert.equal(response.status,200);assert.equal(result.mode,'local_fallback');assert.deepEqual(result.answer.lines,['علی — هفتم الف']);
 const inFlight=fetch(base+'/api/schools/s/assistant',{method:'POST',headers,body:JSON.stringify({question:'غایبان hold_revocation ۱۴۰۵/۰۸/۱۲'})});
 for(let i=0;i<100&&!unblock;i++)await new Promise(r=>setTimeout(r,20));assert.ok(unblock,'mock received request');
 const updateDb=new Database(path.join(dir,'nikan.sqlite'));const updated=JSON.parse(updateDb.prepare('SELECT data FROM app_data WHERE school_id=?').get('s').data);updated.staff[0].pass='new-synthetic-password';updateDb.prepare('UPDATE app_data SET data=?,updated_at=? WHERE school_id=?').run(JSON.stringify(updated),Date.now()+1,'s');updateDb.close();unblock();
 response=await inFlight;result=await response.json();assert.equal(response.status,403);assert.ok(!JSON.stringify(result).includes('علی'));
 console.log('AI planner boundary, scoped report and fallback checks passed');
})().catch(error=>{console.error(error);process.exitCode=1}).finally(()=>{if(app)app.kill();if(mock)mock.close();fs.rmSync(dir,{recursive:true,force:true});});
