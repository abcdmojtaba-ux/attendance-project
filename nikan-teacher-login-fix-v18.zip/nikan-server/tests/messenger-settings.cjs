'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const http=require('node:http');
const {spawn,spawnSync}=require('node:child_process');
const Database=require('better-sqlite3');
(async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nikan-msg-settings-'));let child;
 const env={...process.env,DATA_DIR:dir};delete env.MESSENGER_SECRET;delete env.DB_PATH;
 const seeded=spawnSync(process.execPath,['scripts/mother-account.js','--stdin'],{cwd:path.join(__dirname,'..'),env,input:JSON.stringify({user:'syntheticadmin',pass:'syntheticpassword'}),encoding:'utf8'});assert.equal(seeded.status,0,seeded.stderr);
 const sock=http.createServer();await new Promise(r=>sock.listen(0,'127.0.0.1',r));const port=sock.address().port;await new Promise(r=>sock.close(r));
 const headers={'content-type':'application/json','X-Auth-User':'syntheticadmin','X-Auth-Pass':'syntheticpassword','X-Auth-Role':'mother'};const base='http://127.0.0.1:'+port;
 async function start(secret){if(secret)env.MESSENGER_SECRET=secret;else delete env.MESSENGER_SECRET;child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...env,PORT:String(port)},stdio:'ignore'});for(let i=0;i<100;i++){try{if((await fetch(base+'/api/health')).ok)return;}catch{} await new Promise(r=>setTimeout(r,100));}throw Error('server not ready');}
 async function stop(){if(child){child.kill();await new Promise(r=>child.once('exit',r));child=null;}}
 async function put(body,h=headers){const r=await fetch(base+'/api/messenger',{method:'PUT',headers:h,body:JSON.stringify(body)});return {status:r.status,body:await r.json()};}
 try{
 await start();
 let status=await fetch(base+'/api/messenger',{headers}).then(x=>x.json());assert.equal(status.config.secretMode,'automatic');assert.equal(status.config.keySet,false);
 let r=await put({provider:'eitaa',apiKey:'synthetic-key'}, {'content-type':'application/json'});assert.equal(r.status,401);
 r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.body.error,'api_key_required');
 r=await put({provider:'eitaa',enabled:true,apiKey:'bad value',contacts:{}});assert.equal(r.body.error,'invalid_key');
 r=await put({provider:'eitaa',apiKey:'synthetic-key',contacts:{bad:'fake'}});assert.equal(r.body.error,'invalid_contact');
 r=await put({provider:'eitaa',apiKey:'synthetic-key',schoolIds:['unknown']});assert.equal(r.body.error,'invalid_school');
 r=await put({provider:'shad',enabled:true,apiKey:'synthetic-key'});assert.equal(r.body.error,'service_id_required');
 r=await put({provider:'eitaa',enabled:true,apiKey:' \nsynthetic-key  ',contacts:{}});assert.equal(r.status,200);assert.equal(r.body.config.keySet,true);assert.ok(!('key' in r.body.config));
 const secretFile=path.join(dir,'.messenger-secret');assert.equal(fs.statSync(secretFile).mode&0o777,0o600);const firstSecret=fs.readFileSync(secretFile,'utf8');assert.match(firstSecret,/^[0-9a-f]{64}$/);
 let db=new Database(path.join(dir,'nikan.sqlite'),{readonly:true});let config=db.prepare('select data from messenger_config').get().data;assert.ok(!config.includes('synthetic-key'));assert.ok(JSON.parse(config).key.startsWith('file1:'));db.close();
 assert.equal((await fetch(base+'/.messenger-secret')).status,404);
 await stop();await start();r=await put({provider:'eitaa',enabled:true,apiKey:'',contacts:{}});assert.equal(r.status,200);assert.equal(fs.readFileSync(secretFile,'utf8'),firstSecret);
 await stop();await start('x'.repeat(32));r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.status,200);assert.equal(fs.readFileSync(secretFile,'utf8'),firstSecret);
 await stop();fs.renameSync(secretFile,secretFile+'.bak');await start();
 status=await fetch(base+'/api/messenger',{headers}).then(x=>x.json());assert.equal(status.config.keyProblem,'messenger_secret_missing');
 r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.body.error,'messenger_secret_missing');assert.equal(fs.existsSync(secretFile),false);
 r=await put({provider:'eitaa',enabled:true,apiKey:'replacement-key',contacts:{}});assert.equal(r.status,200);assert.equal(fs.statSync(secretFile).mode&0o777,0o600);
 await stop();fs.unlinkSync(secretFile);fs.renameSync(secretFile+'.bak',secretFile);fs.chmodSync(secretFile,0o644);await start();
 r=await put({provider:'eitaa',enabled:true,apiKey:'repair-test-key',contacts:{}});assert.equal(r.status,200);assert.equal(fs.statSync(secretFile).mode&0o777,0o600);
 await stop();fs.writeFileSync(secretFile,'corrupted');await start();r=await put({provider:'eitaa',enabled:true,apiKey:'new-test-key',contacts:{}});assert.equal(r.body.error,'messenger_secret_corrupt');assert.equal(fs.readFileSync(secretFile,'utf8'),'corrupted');await stop();fs.writeFileSync(secretFile,firstSecret);

 // Legacy environment-encrypted keys remain readable with the original configured secret.
 await start('y'.repeat(32));r=await put({provider:'eitaa',enabled:true,apiKey:'legacy-synthetic',contacts:{}});assert.equal(r.status,200);
 await stop();await start('y'.repeat(32));r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.status,200);
 await stop();await start('z'.repeat(32));r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.body.error,'messenger_key_unreadable');
 await stop();await start();r=await put({provider:'eitaa',enabled:true,contacts:{}});assert.equal(r.body.error,'messenger_secret_required');
 // Concurrent workers racing to initialize one data directory all use the same complete key.
 const race=fs.mkdtempSync(path.join(dir,'race-'));const secretModule=path.resolve(__dirname,'../lib/messenger-secret.js');
 const worker="const fs=require('node:fs'),p=require('node:path');const s=require(process.argv[1]).createSecretStore(undefined,process.argv[2]);const key=s.writeKey().key;const saved=fs.readFileSync(p.join(process.argv[2],'.messenger-secret'),'utf8');if(key.toString('hex')!==saved)process.exit(1);";
 await Promise.all(Array.from({length:8},()=>new Promise((resolve,reject)=>{const p=spawn(process.execPath,['-e',worker,secretModule,race],{stdio:'ignore'});p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(Error('concurrent key initialization failed')));})));assert.equal(fs.readdirSync(race).filter(x=>x!=='.messenger-secret').length,0);
 console.log('Automatic key storage, restart, permissions, authenticated save, legacy secret and refusal to silently regenerate passed');
 }finally{await stop();fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
