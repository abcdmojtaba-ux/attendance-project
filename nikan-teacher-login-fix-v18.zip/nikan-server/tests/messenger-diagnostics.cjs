'use strict';
const assert=require('node:assert/strict'),Database=require('better-sqlite3');const {createMessenger}=require('../lib/messenger');
(async()=>{
 const db=new Database(':memory:');let response={ok:true,status:200,json:async()=>({ok:true,result:{id:123}})};const urls=[];
 const m=createMessenger({sqlite:db,secret:'z'.repeat(32),loadSchoolRow:()=>({name:'School',active:true}),schoolUnavailable:()=>false,loadAppData:()=>({students:[],attendance:[]}),normalizeDateToIso:x=>x,transport:async(url,opts)=>{urls.push({url,method:opts.method});if(response instanceof Error)throw response;return response;}});
 assert.equal((await m.checkConnection()).status,'key_missing');m.configure({provider:'eitaa',enabled:true,apiKey:'synthetic-key'});
 assert.equal((await m.checkConnection()).status,'connected');assert.equal(urls[0].method,'GET');assert.match(urls[0].url,/\/getMe$/);
 response={ok:false,status:401,json:async()=>{throw Error('bad body');}};assert.equal((await m.checkConnection()).status,'authentication');
 response={ok:true,status:200,json:async()=>({ok:false,error_code:403})};assert.equal((await m.checkConnection()).status,'authentication');
 response={ok:false,status:429};assert.equal((await m.checkConnection()).status,'rate_limit');
 response=new Error('offline');assert.equal((await m.checkConnection()).status,'unavailable');
 m.configure({provider:'shad',enabled:true,apiKey:'another-key',serviceId:10});assert.equal((await m.checkConnection()).status,'unsupported');
 db.close();console.log('Read-only provider check maps success, key rejection, rate limit and network failures without exposing provider output');
})().catch(e=>{console.error(e);process.exitCode=1});
