// CodeRabbit: verify public metadata and canonical/robots consistency without search-engine assumptions.
const assert=require('node:assert/strict'),fs=require('node:fs');const S=require('../lib/search-pages');
for(const file of ['school.html','parents.html']){
 const html=S.renderSearchPage(fs.readFileSync(require('node:path').join(__dirname,'..',file),'utf8'),file);
 assert.equal((html.match(/rel="canonical"/g)||[]).length,1);assert.ok(html.includes('index,follow,max-image-preview:large'));assert.ok(html.includes(file==='school.html'?'پنل مدرسه نیکان':'پنل والدین نیکان'));
 const schema=JSON.parse(html.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1]);assert.equal(schema['@graph'][2].url,'https://nikan-school.top/'+(file==='school.html'?'school':'parents'));
}
const custom=S.renderSearchPage('<html><head><title>عنوان سفارشی</title><meta name="description" content="توضیح سفارشی"><link rel="canonical" href="https://nikan-school.top/"></head></html>','home.html','https://example.com');assert.ok(custom.includes('<title>عنوان سفارشی</title>'));assert.ok(custom.includes('href="https://example.com/"'));assert.ok(custom.includes('توضیح سفارشی'));
assert.ok(!S.robots().includes('Disallow: /parents'));assert.ok(!S.robots().includes('Disallow: /school'));assert.ok(S.robots().includes('Disallow: /api/'));assert.ok(S.sitemap().includes('/parents</loc>'));assert.ok(S.sitemap().includes('/school</loc>'));assert.ok(!S.sitemap().includes('/site</loc>'));assert.ok(!S.sitemap().includes('lastmod'));assert.equal(S.publicOrigin('javascript:alert(1)'),'https://nikan-school.top');assert.ok(S.renderSearchPage('<html><head></head></html>','mother.html').includes('noindex,nofollow'));console.log('Public SEO title, schema, canonical, robots, sitemap and private-panel tests passed');

assert.ok(require('../lib/website-content').normalize({seoTitle:'سامانه حضور و غیاب مدارس نیکان | مدیریت هوشمند مدارس'}).seoTitle.startsWith('سامانه نیکان'));
assert.ok(require('../lib/parent-branding').normalize({pageTitle:'سامانه جامع نیکان | پنل والدین'}).pageTitle.startsWith('پنل والدین نیکان'));
