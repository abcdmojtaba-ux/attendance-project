'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),D=require('better-sqlite3');
const {spawn,spawnSync}=require('node:child_process');
(async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nikan-delivery-'));let child;
 const env={...process.env,DATA_DIR:dir};delete env.DB_PATH;delete env.MESSENGER_SECRET;
 const init=spawnSync(process.execPath,['scripts/mother-account.js','--stdin'],{cwd:path.join(__dirname,'..'),env,input:JSON.stringify({user:'mother-test',pass:'test-pass'}),encoding:'utf8'});assert.equal(init.status,0,init.stderr);
 const db=new D(path.join(dir,'nikan.sqlite'));const now=Date.now(),date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran'}).format(now);
 for(const n of [1,2]){
  const id='s'+n,school={id,code:'S'+n,name:'School '+n,active:true,expireDate:'2099-01-01',managerUsername:'manager'+n,managerPassword:'test-pass'};
  const data={managerUser:'manager'+n,managerPass:'test-pass',classes:[{id:'c'+n,name:'Class',shift:1}],students:[{id:'p'+n,classId:'c'+n,name:'Student '+n,phones:['0912000000'+n]},{id:'no'+n,classId:'c'+n,name:'No phone '+n,phones:[]}],staff:[{id:'t'+n,username:'teacher'+n,pass:'test-pass',role:'teacher'}],assignments:[{id:'a'+n,teacherId:'t'+n,classId:'c'+n}],attendance:[],updatedAtMs:now};
  db.prepare('INSERT INTO schools(id,code,manager_username,data,updated_at) VALUES(?,?,?,?,?)').run(id,'S'+n,'manager'+n,JSON.stringify(school),now);
  db.prepare('INSERT INTO app_data(school_id,data,updated_at) VALUES(?,?,?)').run(id,JSON.stringify(data),now);
 }db.close();
 const server=http.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;await new Promise(r=>server.close(r));
 child=spawn(process.execPath,['--require',path.join(__dirname,'fixtures/messenger-fake-transport.cjs'),'server.js'],{cwd:path.join(__dirname,'..'),env:{...env,PORT:String(port)},stdio:'ignore'});const base='http://127.0.0.1:'+port;
 const headers=user=>({'content-type':'application/json','X-Auth-User':user,'X-Auth-Pass':'test-pass','X-Auth-Role':'mother'});
 async function req(url,user,method='GET',body){const res=await fetch(base+url,{method,headers:headers(user),...(body?{body:JSON.stringify(body)}:{})});return {status:res.status,body:await res.json()};}
 try{
  let ready=false;for(let i=0;i<100;i++){try{if((await fetch(base+'/api/health')).ok){ready=true;break;}}catch{} await new Promise(r=>setTimeout(r,100));}assert.ok(ready);
  let r=await req('/api/messenger','mother-test','PUT',{provider:'eitaa',enabled:true,apiKey:'synthetic-key',contacts:{}});assert.equal(r.status,200);
  r=await req('/api/messenger/check','mother-test','POST',{});assert.equal(r.body.status,'authentication');
  r=await req('/api/messenger/check','manager1','POST',{schoolId:'s1'});assert.equal(r.status,403);
  const attendance=[{id:'abs1',studentId:'p1',classId:'c1',date,type:'absent'},{id:'late1',studentId:'no1',classId:'c1',date,type:'late'}];
  r=await req('/api/schools/s1/appData','manager1','PUT',{_softOnly:true,attendance});assert.equal(r.status,200);
  r=await req('/api/schools/s1/messenger/status','manager1');assert.equal(r.status,200);assert.equal(r.body.active,true);assert.equal(r.body.items.length,2);assert.ok(r.body.items.some(x=>x.student==='No phone 1'&&x.status==='missing_phone'));
  for(let i=0;i<60&&!r.body.items.some(x=>x.status==='rejected');i++){await new Promise(ok=>setTimeout(ok,100));r=await req('/api/schools/s1/messenger/status','manager1');}
  assert.ok(r.body.items.some(x=>x.student==='Student 1'&&x.status==='rejected'&&x.reason==='authentication'));assert.ok(!JSON.stringify(r.body).includes('09120000001'));assert.ok(!JSON.stringify(r.body).includes('synthetic-key'));
  r=await req('/api/schools/s1/messenger/status','teacher1');assert.equal(r.status,403);
  r=await req('/api/schools/s1/messenger/status','manager2');assert.equal(r.status,401);
  r=await req('/api/schools/s2/messenger/status','manager2');assert.equal(r.status,200);assert.equal(r.body.items.length,0);
  r=await req('/api/messenger','mother-test');assert.ok(r.body.logs.some(x=>x.reason==='authentication'));assert.ok(!JSON.stringify(r.body).includes('synthetic-key'));
  console.log('Persisted school attendance, no-phone diagnostic, fake provider rejection and school/role isolation passed');
 }finally{child.kill();await new Promise(r=>child.once('exit',r));fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1});
