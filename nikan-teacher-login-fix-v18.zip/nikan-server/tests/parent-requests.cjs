const assert = require('node:assert/strict');
const Database = require('better-sqlite3');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nikan-exam-test-'));
let child;
(async () => {
 const server = http.createServer(); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); const port=server.address().port; await new Promise(resolve => server.close(resolve));
 child = spawn(process.execPath, ['server.js'], {cwd:path.join(__dirname, '..'), env:{...process.env,DATA_DIR:dir,PORT:String(port),MOTHER_KEY:'synthetic-mother-key',MESSENGER_SECRET:'x'.repeat(32)},stdio:'ignore'});
 const base='http://127.0.0.1:'+port; let ready=false;
 for(let i=0;i<100;i++){try{const response=await fetch(base+'/api/health');if(response.ok){ready=true;break}}catch{} await new Promise(resolve=>setTimeout(resolve,100));}
 if(!ready)throw Error('server failed to start');
 const dbpath=path.join(dir,'nikan.sqlite');
 const db = new Database(dbpath);
db.prepare('DELETE FROM parent_online_exam_sessions').run(); db.prepare('DELETE FROM parent_sessions').run(); db.prepare('DELETE FROM parent_accounts').run();
const now=Date.now();
const school={id:'testschool',code:'S1',name:'Test',active:true,expireDate:'2099-01-01',modules:['parent_portal'],managerUsername:'manager',managerPassword:'testpass'};
const data={managerUser:'manager',managerPass:'testpass',classes:[{id:'c1',name:'class 1'},{id:'c2',name:'class 2'}],students:[{id:'s1',name:'Student',classId:'c1',phone:'09121234567'}],staff:[{id:'t1',name:'Teacher',username:'teacher',pass:'testpass',role:'teacher'},{id:'t2',name:'Other',username:'other',pass:'testpass',role:'teacher'}],assignments:[{id:'a1',teacherId:'t1',classId:'c1'},{id:'a2',teacherId:'t2',classId:'c2'}],onlineExams:[],onlineExamAttempts:[],attendance:[{id:'abs1',studentId:'s1',classId:'c1',type:'absent',date:'2026-11-01'},{id:'abs2',studentId:'s1',classId:'c1',type:'absent',date:'2026-11-02'}],submissions:[],exams:[],updatedAtMs:now};
db.prepare('INSERT OR REPLACE INTO schools(id,code,manager_username,data,updated_at) VALUES(?,?,?,?,?)').run('testschool','S1','manager',JSON.stringify(school),now);
db.prepare('INSERT OR REPLACE INTO app_data(school_id,data,updated_at) VALUES(?,?,?)').run('testschool',JSON.stringify(data),now);
db.close();
const staffHeaders={'content-type':'application/json','X-Auth-User':'teacher','X-Auth-Pass':'testpass','X-Auth-Role':'teacher'};
async function req(path,opts={}) { const response=await fetch(base+path,opts); const json=await response.json(); return {response,json}; }

let r=await req('/api/parents/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({phone:'09121234567',password:'123456'})});assert.equal(r.response.status,200);let cookie=r.response.headers.get('set-cookie').split(';')[0];
r=await req('/api/parents/password',{method:'POST',headers:{'content-type':'application/json',cookie},body:JSON.stringify({password:'Synthetic-pass-7'})});assert.equal(r.response.status,200);cookie=r.response.headers.get('set-cookie').split(';')[0];
const headers={'content-type':'application/json',cookie};const payload={schoolId:'testschool',studentId:'s1',dates:['2026-11-01'],note:'توضیح بدون عکس'};
const send=body=>req('/api/parents/requests',{method:'POST',headers,body:JSON.stringify(body)});
r=await send({...payload,note:'  '});assert.equal(r.response.status,400);
r=await send({...payload,studentId:'other'});assert.equal(r.response.status,404);
const attempts=await Promise.all([send(payload),send(payload),send(payload)]);assert.equal(attempts.filter(x=>x.response.status===201).length,1);assert.equal(attempts.filter(x=>x.response.status===409).length,2);const id=attempts.find(x=>x.response.status===201).json.id;
r=await req('/api/parents/students/testschool/s1',{headers:{cookie}});assert.equal(r.json.requests.length,1);assert.equal(r.json.requests[0].note,payload.note);assert.equal(r.json.requests[0].fileName,'');
r=await req('/api/parents/requests/'+id+'/file',{headers:{cookie}});assert.equal(r.response.status,404);
const manager={'content-type':'application/json','X-Auth-User':'manager','X-Auth-Pass':'testpass','X-Auth-Role':'manager'};
r=await req('/api/schools/testschool/parent-requests',{headers:manager});assert.equal(r.response.status,200);assert.equal(r.json.requests[0].fileName,'');
r=await req('/api/schools/testschool/parent-requests/'+id+'/review',{method:'POST',headers:manager,body:JSON.stringify({status:'approved',note:'بررسی شد'})});assert.equal(r.response.status,200,JSON.stringify(r.json));
r=await req('/api/parents/students/testschool/s1',{headers:{cookie}});assert.ok(r.json.report.absences.find(a=>a.date==='2026-11-01').excused);
r=await send({...payload,dates:['2026-11-02'],file:{name:'bad.txt',data:'data:text/plain;base64,YQ=='}});assert.equal(r.response.status,400);
const file={name:'certificate.png',data:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aE3sAAAAASUVORK5CYII='};
r=await send({...payload,dates:['2026-11-02'],file});assert.equal(r.response.status,201);const fileId=r.json.id;
const download=await fetch(base+'/api/parents/requests/'+fileId+'/file',{headers:{cookie}});assert.equal(download.status,200);assert.equal(download.headers.get('content-type'),'image/png');assert.ok((await download.arrayBuffer()).byteLength>8);
console.log('Parent text-only request, concurrency, validation, authorization, review and attachment checks passed');
})().catch(err=>{console.error(err);process.exitCode=1}).finally(()=>{if(child)child.kill();fs.rmSync(dir,{recursive:true,force:true})});
