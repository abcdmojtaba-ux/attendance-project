'use strict';
// Synthetic provider only; abort if any real provider URL is ever attempted.
const nativeFetch=global.fetch;
global.fetch=async function(url,options){
 if(String(url).startsWith('https://api.uniom.ir/'))return new Response(JSON.stringify({ok:false,error_code:401,description:'synthetic-only'}),{status:401,headers:{'content-type':'application/json'}});
 if(/^https:\/\//.test(String(url)))throw Error('unexpected external request');
 return nativeFetch(url,options);
};
