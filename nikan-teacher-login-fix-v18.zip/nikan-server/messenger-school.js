// Read-only delivery status for the authenticated school manager.
(function(){'use strict';
 const labels={queued:'در صف ارسال',sending:'در حال ارسال',accepted:'پذیرفته‌شده توسط سرویس؛ دریافت تأیید نشده',rejected:'ردشده توسط سرویس',unknown:'نتیجه نامشخص',config_error:'مشکل کلید یا تنظیمات مرکزی',missing_phone:'شماره معتبر والد ثبت نشده',missing_contact:'در انتظار شناسه در نسخه قبلی',cancelled:'لغو شده'};
 const reasons={authentication:'کلید یا دسترسی سرویس پذیرفته نشد',rate_limit:'محدودیت سرویس',request:'درخواست یا مقصد توسط سرویس رد شد',provider_error:'خطای سرویس',invalid_response:'پاسخ سرویس قابل تأیید نبود',network:'ارتباط با سرویس نامشخص'};
 let busy=false,identity='';
 function current(){return JSON.stringify([window.session&&window.session.schoolId,window.userSession&&window.userSession.role,window.userSession&&window.userSession.username]);}
 async function refresh(){
  const host=document.getElementById('school-messenger-status'),session=window.session,user=window.userSession;
  if(!host)return;if(!session||!session.schoolId||!user||user.role!=='manager'){host.hidden=true;host.replaceChildren();identity='';return;}
  const who=current();if(who!==identity){host.replaceChildren();identity=who;}if(busy)return;busy=true;
  try{
   const r=await window.apiFetch('/api/schools/'+encodeURIComponent(session.schoolId)+'/messenger/status',{retries:1,timeoutMs:10000});if(who!==current())return;
   host.hidden=false;host.replaceChildren();const title=document.createElement('div');title.className='card-title';title.textContent='وضعیت اطلاع‌رسانی پیام‌رسان';host.appendChild(title);
   const info=document.createElement('p');info.className='hint';info.textContent=r.active?'ارسال مرکزی '+(r.provider==='eitaa'?'ایتا':'شاد')+' تنظیم شده است. غیبت یا تأخیر جدید پس از ذخیره روی سرور در صف قرار می‌گیرد.':'ارسال مرکزی برای این مدرسه فعال نیست؛ با مدیر سامانه تماس بگیرید.';host.appendChild(info);
   const refreshButton=document.createElement('button');refreshButton.type='button';refreshButton.className='btn btn-outline btn-sm';refreshButton.textContent='به‌روزرسانی وضعیت';refreshButton.onclick=refresh;host.appendChild(refreshButton);
   const list=document.createElement('div');list.style.cssText='max-height:210px;overflow:auto;margin-top:10px';
   if(!r.items.length)list.textContent='هنوز گزارشی برای این مدرسه ثبت نشده است.';
   r.items.forEach(x=>{const line=document.createElement('p');line.className='hint';line.textContent=[x.student,x.date,x.type==='absent'?'غیبت':'تأخیر',x.recipient,labels[x.status]||'وضعیت نامشخص',reasons[x.reason]||''].filter(Boolean).join(' · ');list.appendChild(line);});host.appendChild(list);
  }catch{if(who===current()){host.hidden=false;host.textContent='دریافت وضعیت پیام‌رسان ناموفق بود؛ اتصال سرور را بررسی کنید.';}}
  finally{busy=false;}
 }
 function boot(){const render=window.renderHome;if(typeof render==='function')window.renderHome=function(){const value=render.apply(this,arguments);setTimeout(refresh,0);return value;};refresh();setInterval(refresh,15000);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
