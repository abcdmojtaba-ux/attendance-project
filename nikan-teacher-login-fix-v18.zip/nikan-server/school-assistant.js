(function (global) {
  'use strict';
  var suggestions = ['غایبان امروز را بگو', 'آمار تأخیر دیروز', 'فهرست کلاس‌ها', 'دیروز کی حضور غیاب نفرستاده؟', 'میانگین نمرات', 'برنامه امروز شیفت صبح', 'چطور آزمون آنلاین بسازم؟'];
  var identity = '', busy = false, lastQuestion = '', statusReady = false;
  function node(id) { return document.getElementById(id); }
  function message(role, text, lines) {
    var box = node('assistant-messages'); if (!box) return;
    var card = document.createElement('div'); card.className = 'assistant-message ' + role;
    var paragraph = document.createElement('div'); paragraph.textContent = String(text || ''); card.appendChild(paragraph);
    if (lines && lines.length) {
      var list = document.createElement('ul');
      lines.forEach(function (line) { var item = document.createElement('li'); item.textContent = line; list.appendChild(item); });
      card.appendChild(list);
    }
    box.appendChild(card);
    while (box.children.length > 20) box.removeChild(box.firstChild);
    box.scrollTop = box.scrollHeight;
  }
  function focusInput() {
    var input = node('assistant-input');
    if (!input || input.disabled) return;
    input.focus({preventScroll:true});
    if (global.matchMedia('(max-width:600px)').matches) input.scrollIntoView({block:'center'});
  }
  function key() {
    var session = global.session, user = global.userSession;
    return JSON.stringify([session && session.schoolId, user && user.role, user && (user.staffId || user.username)]);
  }
  function open() {
    if (!global.session || !global.session.schoolId || !global.userSession) return;
    if (identity !== key()) { identity = key(); lastQuestion = ''; node('assistant-messages').replaceChildren(); }
    if (!node('assistant-messages').children.length) message('bot', 'سلام! می‌توانم آمار غیبت و تأخیر، کلاس‌ها، دانش‌آموزان، برنامه و میانگین نمرات را بررسی کنم و روش کار با سامانه را توضیح بدهم.');
    node('assistant-dock').hidden = false;
    node('assistant-launcher').setAttribute('aria-expanded','true');
    var current = key(), send = node('assistant-send'), input = node('assistant-input');
    statusReady = false; send.disabled = true; input.disabled = true;
    node('assistant-service').textContent = 'در حال بررسی وضعیت دستیار...';
    global.apiFetch('/api/schools/' + encodeURIComponent(global.session.schoolId) + '/assistant/status', {retries:1,timeoutMs:10000}).then(function(data){
      if (current !== key()) return;
      node('assistant-service').textContent = data.aiEnabled ? 'برای فهم سؤال، متن پرسش و سؤال قبلی به سرویس هوش مصنوعی تنظیم‌شده ارسال می‌شود. گزارش از داده‌های مجاز مدرسه محاسبه می‌شود.' : 'حالت گزارش داخلی فعال است؛ سؤال‌ها به سرویس بیرونی ارسال نمی‌شوند.';
      statusReady = true; send.disabled = false; input.disabled = false; focusInput();
    }).catch(function(){ if(current === key()) node('assistant-service').textContent = 'بررسی وضعیت دستیار ناموفق بود؛ اتصال را بررسی و دوباره باز کنید.'; });
  }
  async function ask(question) {
    var input = node('assistant-input'), button = node('assistant-send');
    question = String(question || '').trim();
    if (!question || busy || !statusReady || !global.session || !global.session.schoolId) return;
    var requestIdentity = key(); busy = true; button.disabled = true; input.disabled = true;
    message('user', question); input.value = '';
    try {
      var data = await global.apiFetch('/api/schools/' + encodeURIComponent(global.session.schoolId) + '/assistant', { method:'POST', body:{ question:question, previous:lastQuestion }, retries:1, timeoutMs:15000 });
      if (requestIdentity !== key()) return;
      var prefix = data.mode === 'local_fallback' ? 'سرویس هوشمند پاسخ نداد؛ پاسخ گزارش داخلی: ' : '';
      message('bot', prefix + data.answer.message, data.answer.lines);
      if (!/(این روز|همان روز|اون روز|آن روز)/.test(question)) lastQuestion = question;
    } catch (err) {
      if (requestIdentity === key()) message('bot', 'دریافت اطلاعات ناموفق بود. اتصال و ورود خود را بررسی کنید و دوباره تلاش کنید.');
    } finally { busy = false; button.disabled = false; input.disabled = false; if (requestIdentity === key()) focusInput(); }
  }
  function close() {
    if(node('assistant-dock')) node('assistant-dock').hidden=true;
    if(node('assistant-launcher')) {node('assistant-launcher').setAttribute('aria-expanded','false');node('assistant-launcher').focus({preventScroll:true});}
  }
  function inject() {
    if(!node('assistant-launcher')) {
      var button=document.createElement('button');button.type='button';button.id='assistant-launcher';button.title='گفتگو با دستیار نیکان';button.setAttribute('aria-label','باز کردن دستیار نیکان');button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls','assistant-dock');
      button.innerHTML='<svg viewBox="0 0 96 96" fill="none" aria-hidden="true"><defs><linearGradient id="nikan-bot-ring" x1="10" y1="5" x2="84" y2="90" gradientUnits="userSpaceOnUse"><stop stop-color="#54e5d0"/><stop offset=".5" stop-color="#d3b46d"/><stop offset="1" stop-color="#28bfc8"/></linearGradient><linearGradient id="nikan-bot-body" x1="25" y1="25" x2="72" y2="73" gradientUnits="userSpaceOnUse"><stop stop-color="#68e9d7"/><stop offset="1" stop-color="#179dab"/></linearGradient></defs><circle cx="48" cy="48" r="43" fill="#101e46"/><circle cx="48" cy="48" r="40" stroke="url(#nikan-bot-ring)" stroke-width="1.6" opacity=".8"/><g class="assistant-orbit"><ellipse cx="48" cy="48" rx="48" ry="20" transform="rotate(-42 48 48)" stroke="url(#nikan-bot-ring)" stroke-width="2"/><circle cx="12" cy="64" r="3" fill="#d3b46d"/></g><path d="m51 14-7 12h7l-2 8 10-14h-8l3-6" fill="#d3b46d"/><rect x="22" y="32" width="52" height="42" rx="15" fill="url(#nikan-bot-body)"/><rect x="16" y="43" width="7" height="18" rx="3" fill="#42d6cb"/><rect x="73" y="43" width="7" height="18" rx="3" fill="#42d6cb"/><rect x="30" y="39" width="36" height="28" rx="9" fill="#f4fafb"/><g class="assistant-eyes" fill="#101e46"><rect x="37" y="46" width="5" height="9" rx="2.5"/><rect x="54" y="46" width="5" height="9" rx="2.5"/></g><path d="M42 59q6 5 12 0" stroke="#101e46" stroke-width="2.5" stroke-linecap="round"/></svg>';
      button.onclick=function(){if(node('assistant-dock').hidden)open();else close();};document.body.appendChild(button);
      var dock=document.createElement('aside');dock.id='assistant-dock';dock.hidden=true;dock.setAttribute('aria-label','گفتگو با دستیار نیکان');
      var shell=document.querySelector('.assistant-shell');if(shell)dock.appendChild(shell);document.body.appendChild(dock);
      var back=dock.querySelector('.assistant-top button');if(back){back.textContent='بستن';back.removeAttribute('onclick');back.onclick=close;}
      document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!dock.hidden)close();});
    }
    node('assistant-launcher').hidden=!(global.session&&global.session.schoolId&&global.userSession);
  }
  function boot() {
    var form=node('assistant-form');
    if (form && !form.dataset.bound) {
      form.dataset.bound='1'; form.addEventListener('submit',function(e){e.preventDefault();ask(node('assistant-input').value);});
      var hints=node('assistant-hints'); suggestions.forEach(function (text) {var b=document.createElement('button');b.type='button';b.textContent=text;b.addEventListener('click',function(){ask(text);});hints.appendChild(b);});
    }
    if (!global._schoolAssistantHomePatched && typeof global.renderHome === 'function') {
      var original=global.renderHome; global.renderHome=function(){var value=original.apply(this,arguments);inject();return value;};global._schoolAssistantHomePatched=true;
    }
    if (!global._schoolAssistantLogoutPatched && typeof global.doLogout === 'function') {
      var logout=global.doLogout; global.doLogout=function(){close();node('assistant-launcher').hidden=true;identity=''; lastQuestion=''; statusReady=false; if(node('assistant-messages')) node('assistant-messages').replaceChildren(); if(node('assistant-input')) node('assistant-input').value=''; return logout.apply(this,arguments);};global._schoolAssistantLogoutPatched=true;
    }
    inject();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',boot); else boot();
  setTimeout(boot,1500);
})(window);
